using System;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UseCaseApplication;

namespace TestProject
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            // Проверка: расстояние от точки до горизонтального сегмента
            // Точка (5, 5) находится на расстоянии 5 единиц от горизонтального сегмента от (0, 0) до (10, 0)
            Point p = new Point(5, 5);
            Point p1 = new Point(0, 0);
            Point p2 = new Point(10, 0);
            double expected = 5.0; // Ожидаемое расстояние равно 5
            double actual = MainWindow.RasstoyanieDoSegmenta(p, p1, p2);
            Xunit.Assert.Equal(expected, actual, 3); // Проверка с точностью до 3 знаков

            // Проверка: расстояние от точки до вертикального сегмента
            // Точка (5, 5) находится на расстоянии 5 единиц от вертикального сегмента от (0, 0) до (0, 10)
            Point p3 = new Point(5, 5);
            Point p4 = new Point(0, 0);
            Point p5 = new Point(0, 10);
            double expected2 = 5.0;
            double actual2 = MainWindow.RasstoyanieDoSegmenta(p3, p4, p5);
            Xunit.Assert.Equal(expected2, actual2, 3);

            // Проверка: точка на сегменте (расстояние должно быть 0)
            // Точка (5, 0) лежит непосредственно на горизонтальном сегменте от (0, 0) до (10, 0)
            Point p6 = new Point(5, 0);
            double expected3 = 0.0;
            double actual3 = MainWindow.RasstoyanieDoSegmenta(p6, p1, p2);
            Xunit.Assert.Equal(expected3, actual3, 3);
        }

        [Fact]
        public void TestYavlyaetsyaFailomFormataUca()
        {
            // Корректные варианты: файлы с расширением .uca
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("file.uca"));
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("C:\\path\\to\\file.uca"));
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("document.UCA")); // проверка регистронезависимости
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("test.Uca"));
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("myfile.uCa"));
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("C:\\Users\\Documents\\diagram.uca"));

            // Исключительные варианты: null, пустая строка, пробелы
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca(null));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca(""));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("   "));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("\t\n\r"));

            // Неправильные варианты: другие расширения
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.txt"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.doc"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.pdf"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.uc"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.ucaa"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("C:\\path\\file.xml"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.uca.backup"));
        }

        [Fact]
        public void TestPoluchitPathSPravilnymRasshireniem()
        {
            // Корректные варианты: пути с правильным расширением .uca
            Xunit.Assert.Equal("file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.uca"));
            Xunit.Assert.Equal("C:\\path\\to\\file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("C:\\path\\to\\file.uca"));
            Xunit.Assert.Equal("document.UCA", MainWindow.PoluchitPathSPravilnymRasshireniem("document.UCA"));
            Xunit.Assert.Equal("test.Uca", MainWindow.PoluchitPathSPravilnymRasshireniem("test.Uca"));

            // Корректные варианты: пути без расширения или с другим расширением - должны получить .uca
            Xunit.Assert.Equal("file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file"));
            Xunit.Assert.Equal("file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.txt"));
            Xunit.Assert.Equal("C:\\path\\diagram.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("C:\\path\\diagram.doc"));
            Xunit.Assert.Equal("document.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("document.pdf"));

            // Исключительные варианты: null, пустая строка, пробелы
            Xunit.Assert.Null(MainWindow.PoluchitPathSPravilnymRasshireniem(null));
            Xunit.Assert.Equal("", MainWindow.PoluchitPathSPravilnymRasshireniem(""));
            Xunit.Assert.Equal("   ", MainWindow.PoluchitPathSPravilnymRasshireniem("   "));
            Xunit.Assert.Equal("\t\n\r", MainWindow.PoluchitPathSPravilnymRasshireniem("\t\n\r"));

            // Неправильные варианты: пути с похожими расширениями
            Xunit.Assert.Equal("file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.uc"));
            Xunit.Assert.Equal("file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.ucaa"));
            // Path.ChangeExtension заменяет последнее расширение, поэтому "file.uca.backup" становится "file.uca.uca"
            Xunit.Assert.Equal("file.uca.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.uca.backup"));
        }

        [Fact]
        public void TestTekstUdovletvoryaetOgranicheniya()
        {
            // Корректные варианты: текст в пределах ограничений (макс 255 символов, макс 20 на строку)
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("Short text"));
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 19))); // 19 символов в одной строке
            // Тест с несколькими строками, каждая <= 20 символов, общая длина <= 255
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("A\nB\nC"));
            // Тест с несколькими строками по 20 символов каждая
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 20) + "\n" + new string('B', 20))); // две строки по 20 символов

            // Исключительные варианты: null должен вернуть true
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya(null));
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya(""));

            // Неправильные варианты: превышение ограничений
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya("This text contains more than 20 characters!")); // больше 20 в одной строке
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 256))); // больше 255 символов
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 254))); // одна строка 254 символа (больше 20)
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya("A\n" + new string('B', 21) + "\nC")); // одна строка больше 20
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya("123456789012345678901")); // 21 символ в строке
        }

        [Fact]
        public void TestIzmeritTekstovoeSoderzhimoe()
        {
            Exception? exception = null;
            var thread = new Thread(() =>
            {
                try
                {
                    // Инициализация WPF приложения для работы с UI элементами
                    if (System.Windows.Application.Current == null)
                    {
                        new System.Windows.Application();
                    }

                    // Корректные варианты: нормальный текст с параметрами
                    var size1 = MainWindow.IzmeritTekstovoeSoderzhimoe("Test", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(size1.Width > 0);
                    Xunit.Assert.True(size1.Height > 0);

                    var size2 = MainWindow.IzmeritTekstovoeSoderzhimoe("Long text", new FontFamily("Times New Roman"), 16, FontWeights.Bold, 300);
                    Xunit.Assert.True(size2.Width > 0);
                    Xunit.Assert.True(size2.Height > 0);

                    // Корректные варианты: с дефолтными значениями (null, 0, default)
                    var size3 = MainWindow.IzmeritTekstovoeSoderzhimoe("Text", null, 0, default(FontWeight), 200);
                    Xunit.Assert.True(size3.Width > 0);
                    Xunit.Assert.True(size3.Height > 0);

                    // Исключительные варианты: пустой или null текст
                    var size4 = MainWindow.IzmeritTekstovoeSoderzhimoe(null, new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(size4.Width > 0);
                    Xunit.Assert.True(size4.Height > 0);

                    var size5 = MainWindow.IzmeritTekstovoeSoderzhimoe("", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(size5.Width > 0);
                    Xunit.Assert.True(size5.Height > 0);

                    // Неправильные варианты: отрицательные значения размера шрифта
                    var size6 = MainWindow.IzmeritTekstovoeSoderzhimoe("Test", new FontFamily("Arial"), -5, FontWeights.Normal, 200);
                    Xunit.Assert.True(size6.Width > 0);
                    Xunit.Assert.True(size6.Height > 0);
                }
                catch (Exception ex) { exception = ex; }
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            thread.Join();
            if (exception != null) throw exception;
        }

        [Fact]
        public void TestYavlyaetsyaTekstovymKontainerom()
        {
            Exception? exception = null;
            var thread = new Thread(() =>
            {
                try
                {
                    // Инициализация WPF приложения для работы с UI элементами
                    if (System.Windows.Application.Current == null)
                    {
                        new System.Windows.Application();
                    }

                    // Корректные варианты: Border с правильным тегом "uca-user-text"
                    var border1 = new Border { Tag = "uca-user-text" };
                    Xunit.Assert.True(MainWindow.YavlyaetsyaTekstovymKontainerom(border1));

                    var border2 = new Border { Tag = "uca-user-text" };
                    Xunit.Assert.True(MainWindow.YavlyaetsyaTekstovymKontainerom(border2));

                    // Исключительные варианты: null, Border без тега, Border с null тегом
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(null));

                    var border3 = new Border { Tag = null };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(border3));

                    var border4 = new Border();
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(border4));

                    // Неправильные варианты: Border с неправильным тегом, другие элементы
                    var border5 = new Border { Tag = "wrong-tag" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(border5));

                    var border6 = new Border { Tag = "UCA-USER-TEXT" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(border6));

                    var textBlock = new TextBlock { Tag = "uca-user-text" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(textBlock));

                    var button = new Button { Tag = "uca-user-text" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(button));

                    var border7 = new Border { Tag = 123 };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(border7));
                }
                catch (Exception ex) { exception = ex; }
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            thread.Join();
            if (exception != null) throw exception;
        }

        [Fact]
        public void TestEtoPolzovatelskiyTekst()
        {
            Exception? exception = null;
            var thread = new Thread(() =>
            {
                try
                {
                    // Инициализация WPF приложения для работы с UI элементами
                    if (System.Windows.Application.Current == null)
                    {
                        new System.Windows.Application();
                    }

                    // Проверка: TextBlock с правильным тегом "uca-user-text" без текста должен быть распознан как пользовательский текст
                    var textBlock1 = new TextBlock { Tag = "uca-user-text" };
                    Xunit.Assert.True(MainWindow.EtoPolzovatelskiyTekst(textBlock1));

                    // Проверка: TextBlock с правильным тегом "uca-user-text" и с текстом должен быть распознан как пользовательский текст
                    var textBlock2 = new TextBlock { Tag = "uca-user-text", Text = "Test" };
                    Xunit.Assert.True(MainWindow.EtoPolzovatelskiyTekst(textBlock2));

                    // Проверка: TextBlock внутри Border с правильным тегом "uca-user-text" должен быть распознан как пользовательский текст
                    var border = new Border { Tag = "uca-user-text" };
                    var textBlock3 = new TextBlock { Text = "Test" };
                    border.Child = textBlock3;
                    Xunit.Assert.True(MainWindow.EtoPolzovatelskiyTekst(textBlock3));

                    // Проверка: null должен вернуть false (защита от NullReferenceException)
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(null));

                    // Проверка: TextBlock без тега и не находящийся в контейнере не должен быть распознан как пользовательский текст
                    var textBlock4 = new TextBlock { Text = "Test" };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlock4));

                    // Проверка: TextBlock с null тегом не должен быть распознан как пользовательский текст
                    var textBlock5 = new TextBlock { Tag = null, Text = "Test" };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlock5));

                    // Проверка: TextBlock с неправильным тегом не должен быть распознан как пользовательский текст
                    var textBlock6 = new TextBlock { Tag = "wrong-tag" };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlock6));

                    // Проверка: TextBlock с тегом в другом регистре (регистрозависимая проверка) не должен быть распознан как пользовательский текст
                    var textBlock7 = new TextBlock { Tag = "UCA-USER-TEXT" };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlock7));

                    // Проверка: TextBlock внутри Border с неправильным тегом не должен быть распознан как пользовательский текст
                    var border2 = new Border { Tag = "wrong-tag" };
                    var textBlock8 = new TextBlock { Text = "Test" };
                    border2.Child = textBlock8;
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlock8));

                    // Проверка: TextBlock внутри Border без тега не должен быть распознан как пользовательский текст
                    var border3 = new Border();
                    var textBlock9 = new TextBlock { Text = "Test" };
                    border3.Child = textBlock9;
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlock9));
                }
                catch (Exception ex) { exception = ex; }
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            thread.Join();
            if (exception != null) throw exception;
        }
    }
}
