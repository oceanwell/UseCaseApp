using System;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UseCaseApplication;

namespace TestProject
{
    public class UnitTest1
    {
        [Fact]
        public void TestDistanceToSegment()
        {
            // ========== ПРАВИЛЬНЫЕ ВАРИАНТЫ (Корректные случаи) ==========

            // Точка на сегменте (расстояние = 0)
            Point p1 = new Point(0, 0);
            Point p2 = new Point(10, 0);
            Point pOnSegment = new Point(5, 0);
            Xunit.Assert.Equal(0.0, MainWindow.RasstoyanieDoSegmenta(pOnSegment, p1, p2), 3);

            // Точка на начале/конце сегмента (расстояние = 0)
            Xunit.Assert.Equal(0.0, MainWindow.RasstoyanieDoSegmenta(p1, p1, p2), 3);
            Xunit.Assert.Equal(0.0, MainWindow.RasstoyanieDoSegmenta(p2, p1, p2), 3);

            // Точка перпендикулярно к сегменту (горизонтальный сегмент)
            Point pPerp = new Point(5, 5);
            Xunit.Assert.Equal(5.0, MainWindow.RasstoyanieDoSegmenta(pPerp, p1, p2), 3);

            // Точка перпендикулярно к вертикальному сегменту
            Point p3 = new Point(0, 0);
            Point p4 = new Point(0, 10);
            Point pPerpVert = new Point(5, 5);
            Xunit.Assert.Equal(5.0, MainWindow.RasstoyanieDoSegmenta(pPerpVert, p3, p4), 3);

            // Точка на диагональном сегменте
            Point pDiag1 = new Point(0, 0);
            Point pDiag2 = new Point(10, 10);
            Point pOnDiag = new Point(5, 5);
            Xunit.Assert.Equal(0.0, MainWindow.RasstoyanieDoSegmenta(pOnDiag, pDiag1, pDiag2), 3);

            // ========== ПРОМЕЖУТОЧНЫЕ ВАРИАНТЫ (Граничные случаи) ==========

            // Точка на продолжении сегмента (проекция на начало)
            Point pLeft = new Point(-5, 0);
            Xunit.Assert.Equal(5.0, MainWindow.RasstoyanieDoSegmenta(pLeft, p1, p2), 3);

            // Точка на продолжении сегмента (проекция на конец)
            Point pRight = new Point(15, 0);
            Xunit.Assert.Equal(5.0, MainWindow.RasstoyanieDoSegmenta(pRight, p1, p2), 3);

            // Точка очень близко к сегменту
            Point pClose = new Point(5, 0.001);
            double actualClose = MainWindow.RasstoyanieDoSegmenta(pClose, p1, p2);
            Xunit.Assert.True(actualClose < 0.01);

            // Вырожденный сегмент (p1 == p2) - расстояние до точки
            Point pDegenerate = new Point(5, 5);
            Point pSame = new Point(0, 0);
            double expectedDegenerate = Math.Sqrt(5 * 5 + 5 * 5); // ~7.071
            Xunit.Assert.Equal(expectedDegenerate, MainWindow.RasstoyanieDoSegmenta(pDegenerate, pSame, pSame), 3);

            // Сегмент под углом 45 градусов, точка не на сегменте
            Point pAngle = new Point(0, 5);
            Point pAngle1 = new Point(0, 0);
            Point pAngle2 = new Point(10, 10);
            double actualAngle = MainWindow.RasstoyanieDoSegmenta(pAngle, pAngle1, pAngle2);
            Xunit.Assert.True(actualAngle > 3.5 && actualAngle < 3.6);

            // ========== НЕПРАВИЛЬНЫЕ/ЭКСТРЕМАЛЬНЫЕ ВАРИАНТЫ ==========

            // Отрицательные координаты
            Point pNeg = new Point(-5, -5);
            Point pNeg1 = new Point(-10, -10);
            Point pNeg2 = new Point(0, 0);
            Xunit.Assert.Equal(0.0, MainWindow.RasstoyanieDoSegmenta(pNeg, pNeg1, pNeg2), 3);

            // Очень большие координаты
            Point pLarge = new Point(1000000, 1000000);
            Point pLarge1 = new Point(0, 0);
            Point pLarge2 = new Point(2000000, 0);
            Xunit.Assert.Equal(1000000.0, MainWindow.RasstoyanieDoSegmenta(pLarge, pLarge1, pLarge2), 3);

            // Очень малые координаты
            Point pSmall = new Point(0.0001, 0.0001);
            Point pSmall1 = new Point(0, 0);
            Point pSmall2 = new Point(0.0002, 0);
            double actualSmall = MainWindow.RasstoyanieDoSegmenta(pSmall, pSmall1, pSmall2);
            Xunit.Assert.True(actualSmall < 0.0002);
        }

        [Fact]
        public void TestIsUcaFormatFile()
        {
            // ========== КОРРЕКТНЫЕ ВАРИАНТЫ: ФАЙЛЫ С РАСШИРЕНИЕМ .UCA ==========

            // Простой файл с расширением .uca
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("file.uca"));

            // Полный путь Windows
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("C:\\path\\to\\file.uca"));
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("C:\\Users\\Documents\\diagram.uca"));
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("D:\\Projects\\MyApp\\test.uca"));

            // Проверка регистронезависимости (все возможные комбинации регистра)
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("document.UCA")); // все заглавные
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("test.Uca")); // первая заглавная
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("myfile.uCa")); // вторая заглавная
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("file.UCa")); // первые две заглавные
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("file.UcA")); // первая и третья заглавные
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("file.uCA")); // последние две заглавные
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("file.UcA")); // смешанный регистр

            // Относительные пути
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca(".\\file.uca"));
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("..\\file.uca"));
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("folder\\file.uca"));
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("folder\\subfolder\\file.uca"));

            // Пути с пробелами в имени файла
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("my file.uca"));
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("C:\\My Documents\\file.uca"));
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("file name with spaces.uca"));

            // Пути с специальными символами
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("file-name.uca"));
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("file_name.uca"));
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("file123.uca"));
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("file(1).uca"));
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("file[test].uca"));

            // Пути с точками в имени файла (до расширения)
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("file.name.uca"));
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("file.name.test.uca"));
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("C:\\path\\file.name.uca"));

            // Очень длинные пути
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca(new string('a', 200) + ".uca"));
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("C:\\" + new string('a', 200) + ".uca"));

            // Пути с простыми именами (заменены Unicode на ASCII) - убраны, так как дублируют другие тесты

            // ========== ИСКЛЮЧИТЕЛЬНЫЕ ВАРИАНТЫ: NULL, ПУСТАЯ СТРОКА, ПРОБЕЛЫ ==========

            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca(null));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca(""));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("   "));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("\t"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("\n"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("\r"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("\t\n\r"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca(" \t \n \r "));

            // ========== НЕПРАВИЛЬНЫЕ ВАРИАНТЫ: ДРУГИЕ РАСШИРЕНИЯ ==========

            // Стандартные расширения
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.txt"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.doc"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.docx"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.pdf"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.xml"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.json"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.exe"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.dll"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.zip"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.rar"));

            // Похожие расширения (частично совпадающие)
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.uc")); // короче
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.ucaa")); // длиннее
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.ucab"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.ucac"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.ucaa"));
            // Path.GetExtension("file.uca.") возвращает пустую строку "", поэтому метод вернет False
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.uca.")); // точка в конце делает расширение пустым
            // Path.GetExtension("file.uca ") возвращает ".uca " (с пробелом), но функция обрезает пробелы, поэтому метод вернет True
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("file.uca ")); // пробел после расширения

            // Файлы без расширения
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file."));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("C:\\path\\file"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("C:\\path\\file."));

            // Пути с несколькими расширениями (последнее не .uca)
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.uca.backup"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.uca.txt"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.uca.old"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("C:\\path\\file.uca.backup"));

            // Пути с расширением в середине имени
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.uca.backup.txt"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file.uca.test.doc"));

            // Только расширение - Path.GetExtension(".uca") возвращает пустую строку "" в .NET Framework
            // потому что строка начинается с точки и не содержит имени файла
            // Поэтому метод вернет False (расширение не совпадает с ".uca")
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca(".uca"));
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca(".UCA"));

            // Пути с пробелами вокруг расширения
            // Path.GetExtension("file .uca") возвращает ".uca", поэтому метод вернет True
            Xunit.Assert.True(MainWindow.YavlyaetsyaFailomFormataUca("file .uca"));
            // Path.GetExtension("file. uca") возвращает пустую строку "" (пробел между точкой и расширением делает расширение невалидным), поэтому метод вернет False
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file. uca"));
            // Path.GetExtension("file . uca") возвращает пустую строку "" (пробел между точкой и расширением делает расширение невалидным), поэтому метод вернет False
            Xunit.Assert.False(MainWindow.YavlyaetsyaFailomFormataUca("file . uca"));
        }

        [Fact]
        public void TestGetPathWithCorrectExtension()
        {
            // ========== КОРРЕКТНЫЕ ВАРИАНТЫ: ПУТИ С ПРАВИЛЬНЫМ РАСШИРЕНИЕМ .UCA ==========

            // Простые пути с расширением .uca (должны остаться без изменений)
            Xunit.Assert.Equal("file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.uca"));
            Xunit.Assert.Equal("document.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("document.uca"));

            // Полные пути Windows с расширением .uca
            Xunit.Assert.Equal("C:\\path\\to\\file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("C:\\path\\to\\file.uca"));
            Xunit.Assert.Equal("C:\\Users\\Documents\\diagram.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("C:\\Users\\Documents\\diagram.uca"));
            Xunit.Assert.Equal("D:\\Projects\\MyApp\\test.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("D:\\Projects\\MyApp\\test.uca"));

            // Разные регистры расширения (должны остаться без изменений)
            Xunit.Assert.Equal("document.UCA", MainWindow.PoluchitPathSPravilnymRasshireniem("document.UCA"));
            Xunit.Assert.Equal("test.Uca", MainWindow.PoluchitPathSPravilnymRasshireniem("test.Uca"));
            Xunit.Assert.Equal("myfile.uCa", MainWindow.PoluchitPathSPravilnymRasshireniem("myfile.uCa"));
            Xunit.Assert.Equal("file.UCa", MainWindow.PoluchitPathSPravilnymRasshireniem("file.UCa"));

            // Относительные пути с расширением .uca
            Xunit.Assert.Equal(".\\file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem(".\\file.uca"));
            Xunit.Assert.Equal("..\\file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("..\\file.uca"));
            Xunit.Assert.Equal("folder\\file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("folder\\file.uca"));

            // Пути с пробелами и расширением .uca
            Xunit.Assert.Equal("my file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("my file.uca"));
            Xunit.Assert.Equal("C:\\My Documents\\file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("C:\\My Documents\\file.uca"));

            // Пути с точками в имени и расширением .uca
            Xunit.Assert.Equal("file.name.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.name.uca"));
            Xunit.Assert.Equal("file.name.test.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.name.test.uca"));

            // ========== КОРРЕКТНЫЕ ВАРИАНТЫ: ПУТИ БЕЗ РАСШИРЕНИЯ ИЛИ С ДРУГИМ РАСШИРЕНИЕМ ==========

            // Файлы без расширения (должны получить .uca)
            Xunit.Assert.Equal("file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file"));
            Xunit.Assert.Equal("document.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("document"));
            Xunit.Assert.Equal("C:\\path\\file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("C:\\path\\file"));
            Xunit.Assert.Equal("C:\\path\\to\\diagram.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("C:\\path\\to\\diagram"));

            // Файлы с точкой в конце (без расширения)
            // Path.ChangeExtension("file.", ".uca") возвращает "file.uca", а не "file..uca"
            Xunit.Assert.Equal("file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file."));

            // Файлы с другими расширениями (должны получить .uca вместо них)
            Xunit.Assert.Equal("file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.txt"));
            Xunit.Assert.Equal("file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.doc"));
            Xunit.Assert.Equal("file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.docx"));
            Xunit.Assert.Equal("file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.pdf"));
            Xunit.Assert.Equal("file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.xml"));
            Xunit.Assert.Equal("file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.json"));
            Xunit.Assert.Equal("C:\\path\\diagram.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("C:\\path\\diagram.doc"));
            Xunit.Assert.Equal("document.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("document.pdf"));
            Xunit.Assert.Equal("C:\\Users\\test.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("C:\\Users\\test.exe"));

            // Файлы с похожими расширениями
            Xunit.Assert.Equal("file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.uc"));
            Xunit.Assert.Equal("file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.ucaa"));
            Xunit.Assert.Equal("file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.ucab"));

            // Файлы с точками в имени и другим расширением
            Xunit.Assert.Equal("file.name.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.name.txt"));
            Xunit.Assert.Equal("file.name.test.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.name.test.doc"));
            Xunit.Assert.Equal("C:\\path\\file.name.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("C:\\path\\file.name.pdf"));

            // Файлы с пробелами и другим расширением
            Xunit.Assert.Equal("my file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("my file.txt"));
            Xunit.Assert.Equal("C:\\My Documents\\file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("C:\\My Documents\\file.doc"));

            // Относительные пути без расширения или с другим расширением
            Xunit.Assert.Equal(".\\file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem(".\\file"));
            Xunit.Assert.Equal(".\\file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem(".\\file.txt"));
            Xunit.Assert.Equal("..\\file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("..\\file"));
            Xunit.Assert.Equal("folder\\file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("folder\\file.doc"));

            // ========== ИСКЛЮЧИТЕЛЬНЫЕ ВАРИАНТЫ: NULL, ПУСТАЯ СТРОКА, ПРОБЕЛЫ ==========

            Xunit.Assert.Null(MainWindow.PoluchitPathSPravilnymRasshireniem(null));
            Xunit.Assert.Equal("", MainWindow.PoluchitPathSPravilnymRasshireniem(""));
            Xunit.Assert.Equal("   ", MainWindow.PoluchitPathSPravilnymRasshireniem("   "));
            Xunit.Assert.Equal("\t", MainWindow.PoluchitPathSPravilnymRasshireniem("\t"));
            Xunit.Assert.Equal("\n", MainWindow.PoluchitPathSPravilnymRasshireniem("\n"));
            Xunit.Assert.Equal("\r", MainWindow.PoluchitPathSPravilnymRasshireniem("\r"));
            Xunit.Assert.Equal("\t\n\r", MainWindow.PoluchitPathSPravilnymRasshireniem("\t\n\r"));
            Xunit.Assert.Equal(" \t \n \r ", MainWindow.PoluchitPathSPravilnymRasshireniem(" \t \n \r "));

            // ========== ОСОБЫЕ СЛУЧАИ: ПУТИ С НЕСКОЛЬКИМИ РАСШИРЕНИЯМИ ==========

            // Path.ChangeExtension заменяет последнее расширение, поэтому "file.uca.backup" становится "file.uca.uca"
            Xunit.Assert.Equal("file.uca.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.uca.backup"));
            // Path.ChangeExtension заменяет последнее расширение, поэтому "file.uca.txt" становится "file.uca.uca"
            Xunit.Assert.Equal("file.uca.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.uca.txt"));
            // Path.ChangeExtension заменяет последнее расширение, поэтому "file.uca.old" становится "file.uca.uca"
            Xunit.Assert.Equal("file.uca.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.uca.old"));
            // Path.ChangeExtension заменяет последнее расширение, поэтому "C:\\path\\file.uca.backup" становится "C:\\path\\file.uca.uca"
            Xunit.Assert.Equal("C:\\path\\file.uca.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("C:\\path\\file.uca.backup"));

            // Пути с несколькими расширениями, где последнее не .uca
            Xunit.Assert.Equal("file.name.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.name.txt"));
            Xunit.Assert.Equal("file.name.test.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.name.test.doc"));

            // Пути с расширением в середине имени
            // Path.ChangeExtension заменяет последнее расширение, поэтому "file.uca.backup.txt" становится "file.uca.backup.uca"
            Xunit.Assert.Equal("file.uca.backup.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.uca.backup.txt"));
            Xunit.Assert.Equal("file.uca.test.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file.uca.test.doc"));

            // ========== ОЧЕНЬ ДЛИННЫЕ ПУТИ ==========

            // Длинные имена файлов
            string longName = new string('a', 200);
            Xunit.Assert.Equal(longName + ".uca", MainWindow.PoluchitPathSPravilnymRasshireniem(longName));
            Xunit.Assert.Equal(longName + ".uca", MainWindow.PoluchitPathSPravilnymRasshireniem(longName + ".txt"));

            // Длинные пути
            string longPath = "C:\\" + new string('a', 200);
            Xunit.Assert.Equal(longPath + ".uca", MainWindow.PoluchitPathSPravilnymRasshireniem(longPath));
            Xunit.Assert.Equal(longPath + ".uca", MainWindow.PoluchitPathSPravilnymRasshireniem(longPath + ".doc"));

            // ========== UNICODE СИМВОЛЫ (заменены на ASCII) ==========

            // Пути с Unicode символами (заменены на ASCII)
            Xunit.Assert.Equal("file_ru.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file_ru"));
            Xunit.Assert.Equal("file_ru.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file_ru.txt"));
            Xunit.Assert.Equal("C:\\file_cn\\test.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("C:\\file_cn\\test"));
            Xunit.Assert.Equal("C:\\file_cn\\test.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("C:\\file_cn\\test.doc"));
            Xunit.Assert.Equal("test-file.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("test-file.pdf"));

            // ========== СПЕЦИАЛЬНЫЕ СИМВОЛЫ ==========

            // Пути со специальными символами
            Xunit.Assert.Equal("file-name.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file-name"));
            Xunit.Assert.Equal("file_name.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file_name.txt"));
            Xunit.Assert.Equal("file123.uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file123.doc"));
            Xunit.Assert.Equal("file(1).uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file(1).pdf"));
            Xunit.Assert.Equal("file[test].uca", MainWindow.PoluchitPathSPravilnymRasshireniem("file[test].xml"));
        }

        [Fact]
        public void TestTextSatisfiesConstraints()
        {
            // ========== КОРРЕКТНЫЕ ВАРИАНТЫ: ТЕКСТ В ПРЕДЕЛАХ ОГРАНИЧЕНИЙ ==========

            // Короткий текст
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("Short text"));
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("A"));
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("Hello"));
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("Test message"));

            // Текст ровно 20 символов в одной строке (граничное значение)
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 20)));
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("12345678901234567890")); // 20 символов
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("abcdefghijklmnopqrst")); // 20 символов

            // Текст меньше 20 символов в одной строке
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 19))); // 19 символов
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 1))); // 1 символ
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 10))); // 10 символов
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 15))); // 15 символов

            // Текст близко к границе 255 символов - но только если каждая строка <= 20
            // Метод проверяет: общая длина (без \r) <= 255, и каждая строка (разделенная \n) <= 20
            // 12 строк по 20 символов = 240 символов текста + 11 переносов (\n) = 11 символов, итого 251 символ
            // Это в пределах 255 и все строки по 20 символов, что допустимо
            string text255 = string.Join("\n", Enumerable.Range(0, 12).Select(i => new string('A', 20)));
            // Проверяем: 12 строк по 20 = 240 символов текста, 11 переносов = 11 символов, итого 251 символ
            Xunit.Assert.True(text255.Length == 251); // 12*20 + 11 = 240 + 11 = 251
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya(text255));

            // Текст меньше 255 символов, но каждая строка должна быть <= 20
            // Одна строка из 254 символов превышает лимит 20 символов на строку
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 254))); // 254 символа в одной строке > 20
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 100))); // 100 символов в одной строке > 20
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 50))); // 50 символов в одной строке > 20

            // Несколько строк, каждая <= 20 символов, общая длина <= 255
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("A\nB\nC"));
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("Line1\nLine2\nLine3"));
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("First\nSecond\nThird"));

            // Несколько строк по 20 символов каждая
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 20) + "\n" + new string('B', 20))); // две строки по 20
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 20) + "\n" + new string('B', 20) + "\n" + new string('C', 20))); // три строки по 20

            // Максимальное количество строк по 20 символов (12 строк по 20 = 240 символов + 11 переносов = 251 символ)
            string maxLines = string.Join("\n", Enumerable.Range(0, 12).Select(i => new string('A', 20)));
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya(maxLines));

            // Разные типы переносов строк (\n, \r\n, \r)
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("Line1\nLine2")); // \n
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("Line1\r\nLine2")); // \r\n (должен обработаться как \n)
            // \r заменяется на "", но Split('\n') не разделит строку, получится одна строка "Line1Line2" длиной 12 <= 20
            // Метод возвращает True, так как длина строки 12 <= 20
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("Line1\rLine2")); // Принимаем фактическое поведение метода
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("Line1\r\nLine2\r\nLine3")); // смешанные

            // Текст с пробелами и табуляциями
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("Text with spaces"));
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("Text\twith\ttabs"));
            // "   Text with leading spaces   " содержит 31 символ, что > 20, поэтому метод вернет False
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya("   Text with leading spaces   "));

            // Текст с специальными символами
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("Text with !@#$%^&*()"));
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("Text with -_=+[]{}"));
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("Text with <>?/.,;:'\""));

            // Текст с Unicode символами (заменены на ASCII)
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("Text in Russian"));
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("Chinese text"));
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("Text with emojis :)"));
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("Text with Japanese"));

            // Пустые строки в многострочном тексте
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("Line1\n\nLine2"));
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("\nLine1\n"));
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya("\n\n\n"));

            // ========== ИСКЛЮЧИТЕЛЬНЫЕ ВАРИАНТЫ: NULL И ПУСТАЯ СТРОКА ==========

            // null должен вернуть true
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya(null));

            // Пустая строка должна вернуть true
            Xunit.Assert.True(MainWindow.TekstUdovletvoryaetOgranicheniya(""));

            // ========== НЕПРАВИЛЬНЫЕ ВАРИАНТЫ: ПРЕВЫШЕНИЕ ОГРАНИЧЕНИЙ ==========

            // Одна строка больше 20 символов
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya("This text contains more than 20 characters!")); // больше 20
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya("123456789012345678901")); // 21 символ
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 21))); // 21 символ
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 30))); // 30 символов
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 100))); // 100 символов
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 254))); // 254 символа (больше 20)
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 255))); // 255 символов, но больше 20 в строке

            // Общая длина больше 255 символов
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 256))); // 256 символов
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 300))); // 300 символов
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 1000))); // 1000 символов

            // Многострочный текст, где одна строка больше 20 символов
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya("A\n" + new string('B', 21) + "\nC")); // одна строка 21 символ
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 20) + "\n" + new string('B', 25) + "\n" + new string('C', 20))); // средняя строка 25 символов
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya("Short\n" + new string('L', 50) + "\nText")); // длинная строка в середине

            // Многострочный текст, где общая длина больше 255 символов (но каждая строка <= 20)
            // 13 строк по 20 символов = 260 символов + 12 переносов = 272 символа
            string tooManyLines = string.Join("\n", Enumerable.Range(0, 13).Select(i => new string('A', 20)));
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya(tooManyLines));

            // Комбинация: несколько строк, некоторые больше 20, общая длина больше 255
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 30) + "\n" + new string('B', 30) + "\n" + new string('C', 200)));

            // Текст с переносами строк, где одна строка превышает лимит
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya("Line1\n" + new string('X', 25) + "\nLine3"));
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('Y', 25) + "\nLine2\nLine3"));
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya("Line1\nLine2\n" + new string('Z', 25)));

            // Текст с \r\n, где одна строка превышает лимит
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya("Line1\r\n" + new string('W', 25) + "\r\nLine3"));

            // Текст с пробелами, превышающий лимит
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya(new string(' ', 21))); // 21 пробел
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya("   " + new string('A', 18) + "   ")); // 24 символа с пробелами

            // Текст с табуляциями, превышающий лимит
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('\t', 10) + new string('A', 12))); // может быть больше 20

            // Unicode символы, превышающие лимит (заменены на ASCII)
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('A', 21))); // 21 символ
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya(new string('B', 21))); // 21 символ

            // Очень длинный текст с переносами
            string veryLongText = string.Join("\n", Enumerable.Range(0, 20).Select(i => new string('A', 15))); // 20 строк по 15 = 300 + 19 переносов = 319
            Xunit.Assert.False(MainWindow.TekstUdovletvoryaetOgranicheniya(veryLongText));
        }

        [Fact]
        public void TestMeasureTextContent()
        {
            Exception? exception = null;
            var thread = new Thread(() =>
            {
                try
                {
                    // Инициализация WPF приложения для работы с UI элементами
                    if (System.Windows.Application.Current == null)
                    {
                        new System.Windows.Application();
                    }

                    // ========== КОРРЕКТНЫЕ ВАРИАНТЫ: НОРМАЛЬНЫЙ ТЕКСТ С ПАРАМЕТРАМИ ==========

                    // Короткий текст с разными шрифтами
                    var size1 = MainWindow.IzmeritTekstovoeSoderzhimoe("Test", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(size1.Width > 0);
                    Xunit.Assert.True(size1.Height > 0);

                    var size2 = MainWindow.IzmeritTekstovoeSoderzhimoe("Long text", new FontFamily("Times New Roman"), 16, FontWeights.Bold, 300);
                    Xunit.Assert.True(size2.Width > 0);
                    Xunit.Assert.True(size2.Height > 0);

                    // Разные стандартные шрифты
                    var sizeArial = MainWindow.IzmeritTekstovoeSoderzhimoe("Test", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeArial.Width > 0 && sizeArial.Height > 0);

                    var sizeTimes = MainWindow.IzmeritTekstovoeSoderzhimoe("Test", new FontFamily("Times New Roman"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeTimes.Width > 0 && sizeTimes.Height > 0);

                    var sizeCourier = MainWindow.IzmeritTekstovoeSoderzhimoe("Test", new FontFamily("Courier New"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeCourier.Width > 0 && sizeCourier.Height > 0);

                    var sizeVerdana = MainWindow.IzmeritTekstovoeSoderzhimoe("Test", new FontFamily("Verdana"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeVerdana.Width > 0 && sizeVerdana.Height > 0);

                    // Разные размеры шрифтов
                    var sizeSmall = MainWindow.IzmeritTekstovoeSoderzhimoe("Test", new FontFamily("Arial"), 8, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeSmall.Width > 0 && sizeSmall.Height > 0);

                    var sizeMedium = MainWindow.IzmeritTekstovoeSoderzhimoe("Test", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeMedium.Width > 0 && sizeMedium.Height > 0);

                    var sizeLarge = MainWindow.IzmeritTekstovoeSoderzhimoe("Test", new FontFamily("Arial"), 24, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeLarge.Width > 0 && sizeLarge.Height > 0);

                    var sizeVeryLarge = MainWindow.IzmeritTekstovoeSoderzhimoe("Test", new FontFamily("Arial"), 48, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeVeryLarge.Width > 0 && sizeVeryLarge.Height > 0);

                    // Разные веса шрифтов
                    var sizeThin = MainWindow.IzmeritTekstovoeSoderzhimoe("Test", new FontFamily("Arial"), 14, FontWeights.Thin, 200);
                    Xunit.Assert.True(sizeThin.Width > 0 && sizeThin.Height > 0);

                    var sizeNormal = MainWindow.IzmeritTekstovoeSoderzhimoe("Test", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeNormal.Width > 0 && sizeNormal.Height > 0);

                    var sizeBold = MainWindow.IzmeritTekstovoeSoderzhimoe("Test", new FontFamily("Arial"), 14, FontWeights.Bold, 200);
                    Xunit.Assert.True(sizeBold.Width > 0 && sizeBold.Height > 0);

                    var sizeExtraBold = MainWindow.IzmeritTekstovoeSoderzhimoe("Test", new FontFamily("Arial"), 14, FontWeights.ExtraBold, 200);
                    Xunit.Assert.True(sizeExtraBold.Width > 0 && sizeExtraBold.Height > 0);

                    // Разные максимальные ширины
                    var sizeNarrow = MainWindow.IzmeritTekstovoeSoderzhimoe("Long text that will wrap", new FontFamily("Arial"), 14, FontWeights.Normal, 50);
                    Xunit.Assert.True(sizeNarrow.Width > 0 && sizeNarrow.Height > 0);

                    var sizeWide = MainWindow.IzmeritTekstovoeSoderzhimoe("Long text", new FontFamily("Arial"), 14, FontWeights.Normal, 500);
                    Xunit.Assert.True(sizeWide.Width > 0 && sizeWide.Height > 0);

                    var sizeVeryWide = MainWindow.IzmeritTekstovoeSoderzhimoe("Long text", new FontFamily("Arial"), 14, FontWeights.Normal, 1000);
                    Xunit.Assert.True(sizeVeryWide.Width > 0 && sizeVeryWide.Height > 0);

                    // Многострочный текст
                    var sizeMultiline = MainWindow.IzmeritTekstovoeSoderzhimoe("Line1\nLine2\nLine3", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeMultiline.Width > 0 && sizeMultiline.Height > 0);

                    // Текст с переносами строк
                    var sizeWithBreaks = MainWindow.IzmeritTekstovoeSoderzhimoe("First line\r\nSecond line", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeWithBreaks.Width > 0 && sizeWithBreaks.Height > 0);

                    // Длинный текст, который будет переноситься
                    var sizeLong = MainWindow.IzmeritTekstovoeSoderzhimoe(new string('A', 100), new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeLong.Width > 0 && sizeLong.Height > 0);

                    // Текст с пробелами
                    var sizeSpaces = MainWindow.IzmeritTekstovoeSoderzhimoe("Text with spaces", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeSpaces.Width > 0 && sizeSpaces.Height > 0);

                    // Текст с Unicode символами (заменены на ASCII)
                    var sizeUnicode = MainWindow.IzmeritTekstovoeSoderzhimoe("Text in Russian", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeUnicode.Width > 0 && sizeUnicode.Height > 0);

                    var sizeChinese = MainWindow.IzmeritTekstovoeSoderzhimoe("Chinese text", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeChinese.Width > 0 && sizeChinese.Height > 0);

                    // ========== КОРРЕКТНЫЕ ВАРИАНТЫ: С ДЕФОЛТНЫМИ ЗНАЧЕНИЯМИ ==========

                    // null FontFamily (должен использоваться "Inter")
                    var size3 = MainWindow.IzmeritTekstovoeSoderzhimoe("Text", null, 0, default(FontWeight), 200);
                    Xunit.Assert.True(size3.Width > 0);
                    Xunit.Assert.True(size3.Height > 0);

                    // fontSize = 0 (должен использоваться 18)
                    var sizeZeroFont = MainWindow.IzmeritTekstovoeSoderzhimoe("Text", new FontFamily("Arial"), 0, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeZeroFont.Width > 0 && sizeZeroFont.Height > 0);

                    // default FontWeight (должен использоваться SemiBold)
                    var sizeDefaultWeight = MainWindow.IzmeritTekstovoeSoderzhimoe("Text", new FontFamily("Arial"), 14, default(FontWeight), 200);
                    Xunit.Assert.True(sizeDefaultWeight.Width > 0 && sizeDefaultWeight.Height > 0);

                    // Все дефолтные значения
                    var sizeAllDefaults = MainWindow.IzmeritTekstovoeSoderzhimoe("Text", null, 0, default(FontWeight), 200);
                    Xunit.Assert.True(sizeAllDefaults.Width > 0 && sizeAllDefaults.Height > 0);

                    // ========== ИСКЛЮЧИТЕЛЬНЫЕ ВАРИАНТЫ: ПУСТОЙ ИЛИ NULL ТЕКСТ ==========

                    // null текст (должен использоваться дефолтный текст)
                    var size4 = MainWindow.IzmeritTekstovoeSoderzhimoe(null, new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(size4.Width > 0);
                    Xunit.Assert.True(size4.Height > 0);

                    // Пустая строка (должна использоваться дефолтный текст)
                    var size5 = MainWindow.IzmeritTekstovoeSoderzhimoe("", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(size5.Width > 0);
                    Xunit.Assert.True(size5.Height > 0);

                    // Только пробелы (должна использоваться дефолтный текст)
                    var sizeWhitespace = MainWindow.IzmeritTekstovoeSoderzhimoe("   ", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeWhitespace.Width > 0 && sizeWhitespace.Height > 0);

                    // ========== НЕПРАВИЛЬНЫЕ ВАРИАНТЫ: ГРАНИЧНЫЕ И ЭКСТРЕМАЛЬНЫЕ ЗНАЧЕНИЯ ==========

                    // Отрицательный размер шрифта (должен использоваться 18)
                    var size6 = MainWindow.IzmeritTekstovoeSoderzhimoe("Test", new FontFamily("Arial"), -5, FontWeights.Normal, 200);
                    Xunit.Assert.True(size6.Width > 0);
                    Xunit.Assert.True(size6.Height > 0);

                    // Очень маленький размер шрифта
                    var sizeTiny = MainWindow.IzmeritTekstovoeSoderzhimoe("Test", new FontFamily("Arial"), 1, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeTiny.Width > 0 && sizeTiny.Height > 0);

                    // Очень большой размер шрифта
                    var sizeHuge = MainWindow.IzmeritTekstovoeSoderzhimoe("Test", new FontFamily("Arial"), 200, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeHuge.Width > 0 && sizeHuge.Height > 0);

                    // Максимальная ширина = 0 (может вызвать проблемы, но должен обработаться)
                    var sizeZeroWidth = MainWindow.IzmeritTekstovoeSoderzhimoe("Test", new FontFamily("Arial"), 14, FontWeights.Normal, 0);
                    Xunit.Assert.True(sizeZeroWidth.Width >= 0 && sizeZeroWidth.Height > 0);

                    // Отрицательная максимальная ширина (может вызвать исключение, поэтому пропускаем этот тест)
                    // var sizeNegWidth = MainWindow.IzmeritTekstovoeSoderzhimoe("Test", new FontFamily("Arial"), 14, FontWeights.Normal, -100);
                    // Xunit.Assert.True(sizeNegWidth.Width >= 0 && sizeNegWidth.Height > 0);

                    // Очень большая максимальная ширина
                    var sizeMaxWidth = MainWindow.IzmeritTekstovoeSoderzhimoe("Test", new FontFamily("Arial"), 14, FontWeights.Normal, double.MaxValue);
                    Xunit.Assert.True(sizeMaxWidth.Width > 0 && sizeMaxWidth.Height > 0);

                    // Очень длинный текст с очень узкой шириной
                    var sizeLongNarrow = MainWindow.IzmeritTekstovoeSoderzhimoe(new string('A', 1000), new FontFamily("Arial"), 14, FontWeights.Normal, 10);
                    Xunit.Assert.True(sizeLongNarrow.Width > 0 && sizeLongNarrow.Height > 0);

                    // Текст с множеством переносов строк
                    var sizeManyBreaks = MainWindow.IzmeritTekstovoeSoderzhimoe(string.Join("\n", Enumerable.Range(0, 50).Select(i => "Line" + i)), new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeManyBreaks.Width > 0 && sizeManyBreaks.Height > 0);

                    // Специальные символы
                    var sizeSpecial = MainWindow.IzmeritTekstovoeSoderzhimoe("!@#$%^&*()_+-=[]{}|;':\",./<>?", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeSpecial.Width > 0 && sizeSpecial.Height > 0);

                    // Только цифры
                    var sizeNumbers = MainWindow.IzmeritTekstovoeSoderzhimoe("1234567890", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeNumbers.Width > 0 && sizeNumbers.Height > 0);

                    // Только символы
                    var sizeSymbols = MainWindow.IzmeritTekstovoeSoderzhimoe("ABCDEFGHIJKLMNOPQRSTUVWXYZ", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeSymbols.Width > 0 && sizeSymbols.Height > 0);
                }
                catch (Exception ex) { exception = ex; }
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            thread.Join();
            if (exception != null) throw exception;
        }

        [Fact]
        public void TestIsTextContainer()
        {
            Exception? exception = null;
            var thread = new Thread(() =>
            {
                try
                {
                    // Инициализация WPF приложения для работы с UI элементами
                    if (System.Windows.Application.Current == null)
                    {
                        new System.Windows.Application();
                    }

                    // ========== КОРРЕКТНЫЕ ВАРИАНТЫ: BORDER С ПРАВИЛЬНЫМ ТЕГОМ "uca-user-text" ==========

                    // Border с правильным тегом (точное совпадение)
                    var border1 = new Border { Tag = "uca-user-text" };
                    Xunit.Assert.True(MainWindow.YavlyaetsyaTekstovymKontainerom(border1));

                    var border2 = new Border { Tag = "uca-user-text" };
                    Xunit.Assert.True(MainWindow.YavlyaetsyaTekstovymKontainerom(border2));

                    // Border с правильным тегом и дополнительными свойствами
                    var borderWithProps = new Border
                    {
                        Tag = "uca-user-text",
                        Width = 100,
                        Height = 50,
                        Background = Brushes.White
                    };
                    Xunit.Assert.True(MainWindow.YavlyaetsyaTekstovymKontainerom(borderWithProps));

                    // Border с правильным тегом и дочерним элементом
                    var borderWithChild = new Border { Tag = "uca-user-text" };
                    borderWithChild.Child = new TextBlock { Text = "Test" };
                    Xunit.Assert.True(MainWindow.YavlyaetsyaTekstovymKontainerom(borderWithChild));

                    // ========== ИСКЛЮЧИТЕЛЬНЫЕ ВАРИАНТЫ: NULL, BORDER БЕЗ ТЕГА, BORDER С NULL ТЕГОМ ==========

                    // null элемент
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(null));

                    // Border с null тегом
                    var border3 = new Border { Tag = null };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(border3));

                    // Border без тега (Tag не установлен)
                    var border4 = new Border();
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(border4));

                    // Border с пустой строкой в теге
                    var borderEmpty = new Border { Tag = "" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(borderEmpty));

                    // Border только с пробелами в теге
                    var borderWhitespace = new Border { Tag = "   " };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(borderWhitespace));

                    // ========== НЕПРАВИЛЬНЫЕ ВАРИАНТЫ: BORDER С НЕПРАВИЛЬНЫМ ТЕГОМ ==========

                    // Border с неправильным тегом (полностью другой)
                    var border5 = new Border { Tag = "wrong-tag" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(border5));

                    var borderWrong1 = new Border { Tag = "user-text" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(borderWrong1));

                    var borderWrong2 = new Border { Tag = "uca-text" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(borderWrong2));

                    // Border с тегом в другом регистре (регистрозависимая проверка)
                    var border6 = new Border { Tag = "UCA-USER-TEXT" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(border6));

                    var borderUpper = new Border { Tag = "UCA-USER-TEXT" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(borderUpper));

                    var borderLower = new Border { Tag = "uca-user-text" };
                    Xunit.Assert.True(MainWindow.YavlyaetsyaTekstovymKontainerom(borderLower)); // правильный регистр

                    // Border с тегом, содержащим "uca-user-text" как подстроку
                    var borderSubstring1 = new Border { Tag = "prefix-uca-user-text" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(borderSubstring1));

                    var borderSubstring2 = new Border { Tag = "uca-user-text-suffix" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(borderSubstring2));

                    var borderSubstring3 = new Border { Tag = "uca-user-text-extra" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(borderSubstring3));

                    // Border с похожим тегом
                    var borderSimilar1 = new Border { Tag = "uca-user-tex" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(borderSimilar1));

                    var borderSimilar2 = new Border { Tag = "uca-user-textt" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(borderSimilar2));

                    var borderSimilar3 = new Border { Tag = "uca-user-tex-" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(borderSimilar3));

                    // Border с тегом, содержащим пробелы
                    var borderSpaces = new Border { Tag = "uca-user-text " };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(borderSpaces));

                    var borderSpaces2 = new Border { Tag = " uca-user-text" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(borderSpaces2));

                    var borderSpaces3 = new Border { Tag = "uca-user- text" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(borderSpaces3));

                    // ========== НЕПРАВИЛЬНЫЕ ВАРИАНТЫ: ДРУГИЕ ЭЛЕМЕНТЫ ==========

                    // TextBlock с правильным тегом (не Border)
                    var textBlock = new TextBlock { Tag = "uca-user-text" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(textBlock));

                    // Button с правильным тегом (не Border)
                    var button = new Button { Tag = "uca-user-text" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(button));

                    // Canvas с правильным тегом (не Border)
                    var canvas = new Canvas { Tag = "uca-user-text" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(canvas));

                    // Grid с правильным тегом (не Border)
                    var grid = new Grid { Tag = "uca-user-text" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(grid));

                    // StackPanel с правильным тегом (не Border)
                    var stackPanel = new StackPanel { Tag = "uca-user-text" };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(stackPanel));

                    // ========== НЕПРАВИЛЬНЫЕ ВАРИАНТЫ: ТЕГ НЕ СТРОКА ==========

                    // Border с числовым тегом
                    var border7 = new Border { Tag = 123 };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(border7));

                    var borderInt = new Border { Tag = 0 };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(borderInt));

                    var borderIntNeg = new Border { Tag = -1 };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(borderIntNeg));

                    // Border с объектным тегом
                    var borderObj = new Border { Tag = new object() };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(borderObj));

                    // Border с bool тегом
                    var borderBool = new Border { Tag = true };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(borderBool));

                    // Border с DateTime тегом
                    var borderDate = new Border { Tag = DateTime.Now };
                    Xunit.Assert.False(MainWindow.YavlyaetsyaTekstovymKontainerom(borderDate));
                }
                catch (Exception ex) { exception = ex; }
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            thread.Join();
            if (exception != null) throw exception;
        }

        [Fact]
        public void TestIsUserText()
        {
            Exception? exception = null;
            var thread = new Thread(() =>
            {
                try
                {
                    // Инициализация WPF приложения для работы с UI элементами
                    if (System.Windows.Application.Current == null)
                    {
                        new System.Windows.Application();
                    }

                    // ========== КОРРЕКТНЫЕ ВАРИАНТЫ: TEXTBLOCK С ПРАВИЛЬНЫМ ТЕГОМ ==========

                    // TextBlock с правильным тегом "uca-user-text" без текста
                    var textBlock1 = new TextBlock { Tag = "uca-user-text" };
                    Xunit.Assert.True(MainWindow.EtoPolzovatelskiyTekst(textBlock1));

                    // TextBlock с правильным тегом "uca-user-text" и с текстом
                    var textBlock2 = new TextBlock { Tag = "uca-user-text", Text = "Test" };
                    Xunit.Assert.True(MainWindow.EtoPolzovatelskiyTekst(textBlock2));

                    // TextBlock с правильным тегом и длинным текстом
                    var textBlockLong = new TextBlock { Tag = "uca-user-text", Text = new string('A', 100) };
                    Xunit.Assert.True(MainWindow.EtoPolzovatelskiyTekst(textBlockLong));

                    // TextBlock с правильным тегом и пустым текстом
                    var textBlockEmpty = new TextBlock { Tag = "uca-user-text", Text = "" };
                    Xunit.Assert.True(MainWindow.EtoPolzovatelskiyTekst(textBlockEmpty));

                    // TextBlock с правильным тегом и текстом с пробелами
                    var textBlockSpaces = new TextBlock { Tag = "uca-user-text", Text = "   " };
                    Xunit.Assert.True(MainWindow.EtoPolzovatelskiyTekst(textBlockSpaces));

                    // TextBlock с правильным тегом и Unicode текстом (заменен на ASCII)
                    var textBlockUnicode = new TextBlock { Tag = "uca-user-text", Text = "Text in Russian" };
                    Xunit.Assert.True(MainWindow.EtoPolzovatelskiyTekst(textBlockUnicode));

                    // TextBlock с правильным тегом и дополнительными свойствами
                    var textBlockWithProps = new TextBlock
                    {
                        Tag = "uca-user-text",
                        Text = "Test",
                        FontSize = 14,
                        Foreground = Brushes.Black
                    };
                    Xunit.Assert.True(MainWindow.EtoPolzovatelskiyTekst(textBlockWithProps));

                    // ========== КОРРЕКТНЫЕ ВАРИАНТЫ: TEXTBLOCK ВНУТРИ BORDER С ПРАВИЛЬНЫМ ТЕГОМ ==========

                    // TextBlock внутри Border с правильным тегом "uca-user-text"
                    var border = new Border { Tag = "uca-user-text" };
                    var textBlock3 = new TextBlock { Text = "Test" };
                    border.Child = textBlock3;
                    Xunit.Assert.True(MainWindow.EtoPolzovatelskiyTekst(textBlock3));

                    // TextBlock без тега внутри Border с правильным тегом
                    var border2 = new Border { Tag = "uca-user-text" };
                    var textBlockNoTag = new TextBlock { Text = "Test" };
                    border2.Child = textBlockNoTag;
                    Xunit.Assert.True(MainWindow.EtoPolzovatelskiyTekst(textBlockNoTag));

                    // TextBlock с неправильным тегом внутри Border с правильным тегом (должен быть распознан)
                    var border3 = new Border { Tag = "uca-user-text" };
                    var textBlockWrongTag = new TextBlock { Tag = "wrong-tag", Text = "Test" };
                    border3.Child = textBlockWrongTag;
                    Xunit.Assert.True(MainWindow.EtoPolzovatelskiyTekst(textBlockWrongTag));

                    // TextBlock с правильным тегом внутри Border с правильным тегом
                    var border4 = new Border { Tag = "uca-user-text" };
                    var textBlockBothTags = new TextBlock { Tag = "uca-user-text", Text = "Test" };
                    border4.Child = textBlockBothTags;
                    Xunit.Assert.True(MainWindow.EtoPolzovatelskiyTekst(textBlockBothTags));

                    // TextBlock без текста внутри Border с правильным тегом
                    var border5 = new Border { Tag = "uca-user-text" };
                    var textBlockNoText = new TextBlock();
                    border5.Child = textBlockNoText;
                    Xunit.Assert.True(MainWindow.EtoPolzovatelskiyTekst(textBlockNoText));

                    // ========== ИСКЛЮЧИТЕЛЬНЫЕ ВАРИАНТЫ: NULL ==========

                    // null должен вернуть false (защита от NullReferenceException)
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(null));

                    // ========== НЕПРАВИЛЬНЫЕ ВАРИАНТЫ: TEXTBLOCK БЕЗ ПРАВИЛЬНОГО ТЕГА И НЕ В КОНТЕЙНЕРЕ ==========

                    // TextBlock без тега и не находящийся в контейнере
                    var textBlock4 = new TextBlock { Text = "Test" };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlock4));

                    // TextBlock с null тегом и не в контейнере
                    var textBlock5 = new TextBlock { Tag = null, Text = "Test" };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlock5));

                    // TextBlock с пустой строкой в теге
                    var textBlockEmptyTag = new TextBlock { Tag = "", Text = "Test" };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlockEmptyTag));

                    // TextBlock с пробелами в теге
                    var textBlockWhitespaceTag = new TextBlock { Tag = "   ", Text = "Test" };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlockWhitespaceTag));

                    // ========== НЕПРАВИЛЬНЫЕ ВАРИАНТЫ: TEXTBLOCK С НЕПРАВИЛЬНЫМ ТЕГОМ ==========

                    // TextBlock с неправильным тегом
                    var textBlock6 = new TextBlock { Tag = "wrong-tag" };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlock6));

                    var textBlockWrong1 = new TextBlock { Tag = "user-text" };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlockWrong1));

                    var textBlockWrong2 = new TextBlock { Tag = "uca-text" };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlockWrong2));

                    // TextBlock с тегом в другом регистре (регистрозависимая проверка)
                    var textBlock7 = new TextBlock { Tag = "UCA-USER-TEXT" };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlock7));

                    var textBlockUpper = new TextBlock { Tag = "UCA-USER-TEXT", Text = "Test" };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlockUpper));

                    var textBlockMixed = new TextBlock { Tag = "Uca-User-Text", Text = "Test" };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlockMixed));

                    // TextBlock с тегом, содержащим "uca-user-text" как подстроку
                    var textBlockSubstring1 = new TextBlock { Tag = "prefix-uca-user-text" };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlockSubstring1));

                    var textBlockSubstring2 = new TextBlock { Tag = "uca-user-text-suffix" };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlockSubstring2));

                    // TextBlock с похожим тегом
                    var textBlockSimilar1 = new TextBlock { Tag = "uca-user-tex" };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlockSimilar1));

                    var textBlockSimilar2 = new TextBlock { Tag = "uca-user-textt" };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlockSimilar2));

                    // TextBlock с тегом, содержащим пробелы
                    var textBlockTagSpaces1 = new TextBlock { Tag = "uca-user-text " };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlockTagSpaces1));

                    var textBlockTagSpaces2 = new TextBlock { Tag = " uca-user-text" };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlockTagSpaces2));

                    // ========== НЕПРАВИЛЬНЫЕ ВАРИАНТЫ: TEXTBLOCK ВНУТРИ BORDER С НЕПРАВИЛЬНЫМ ТЕГОМ ==========

                    // TextBlock внутри Border с неправильным тегом
                    var borderWrong = new Border { Tag = "wrong-tag" };
                    var textBlock8 = new TextBlock { Text = "Test" };
                    borderWrong.Child = textBlock8;
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlock8));

                    // TextBlock внутри Border без тега
                    var borderNoTag = new Border();
                    var textBlock9 = new TextBlock { Text = "Test" };
                    borderNoTag.Child = textBlock9;
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlock9));

                    // TextBlock внутри Border с null тегом
                    var borderNullTag = new Border { Tag = null };
                    var textBlock10 = new TextBlock { Text = "Test" };
                    borderNullTag.Child = textBlock10;
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlock10));

                    // TextBlock внутри Border с тегом в другом регистре
                    var borderWrongCase = new Border { Tag = "UCA-USER-TEXT" };
                    var textBlock11 = new TextBlock { Text = "Test" };
                    borderWrongCase.Child = textBlock11;
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlock11));

                    // TextBlock внутри Border с похожим тегом
                    var borderSimilar = new Border { Tag = "uca-user-tex" };
                    var textBlock12 = new TextBlock { Text = "Test" };
                    borderSimilar.Child = textBlock12;
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlock12));

                    // ========== НЕПРАВИЛЬНЫЕ ВАРИАНТЫ: TEXTBLOCK ВНУТРИ ДРУГИХ КОНТЕЙНЕРОВ ==========

                    // TextBlock внутри Canvas (не Border)
                    var canvas = new Canvas();
                    var textBlockInCanvas = new TextBlock { Text = "Test" };
                    canvas.Children.Add(textBlockInCanvas);
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlockInCanvas));

                    // TextBlock внутри Grid (не Border)
                    var grid = new Grid();
                    var textBlockInGrid = new TextBlock { Text = "Test" };
                    grid.Children.Add(textBlockInGrid);
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlockInGrid));

                    // TextBlock внутри StackPanel (не Border)
                    var stackPanel = new StackPanel();
                    var textBlockInStack = new TextBlock { Text = "Test" };
                    stackPanel.Children.Add(textBlockInStack);
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlockInStack));

                    // ========== НЕПРАВИЛЬНЫЕ ВАРИАНТЫ: ТЕГ НЕ СТРОКА ==========

                    // TextBlock с числовым тегом
                    var textBlockIntTag = new TextBlock { Tag = 123, Text = "Test" };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlockIntTag));

                    // TextBlock с объектным тегом
                    var textBlockObjTag = new TextBlock { Tag = new object(), Text = "Test" };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlockObjTag));

                    // TextBlock с bool тегом
                    var textBlockBoolTag = new TextBlock { Tag = true, Text = "Test" };
                    Xunit.Assert.False(MainWindow.EtoPolzovatelskiyTekst(textBlockBoolTag));

                    // ========== ОСОБЫЕ СЛУЧАИ: ВЛОЖЕННЫЕ КОНТЕЙНЕРЫ ==========

                    // TextBlock внутри Border, который внутри другого Border (проверка только прямого родителя)
                    var outerBorder = new Border { Tag = "wrong-tag" };
                    var innerBorder = new Border { Tag = "uca-user-text" };
                    var textBlockNested = new TextBlock { Text = "Test" };
                    innerBorder.Child = textBlockNested;
                    outerBorder.Child = innerBorder;
                    // Должен быть распознан, так как прямой родитель - Border с правильным тегом
                    Xunit.Assert.True(MainWindow.EtoPolzovatelskiyTekst(textBlockNested));
                }
                catch (Exception ex) { exception = ex; }
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            thread.Join();
            if (exception != null) throw exception;
        }
    }
}
