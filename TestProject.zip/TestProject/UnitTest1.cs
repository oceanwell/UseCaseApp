using System;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UseCaseApplication;

namespace TestProject
{
    public class UnitTest1
    {
        [Fact]
        public void TestDistanceToSegment()
        {
            // ========== ПРАВИЛЬНЫЕ ВАРИАНТЫ (Корректные случаи) ==========

            // Точка на сегменте (расстояние = 0)
            Point p1 = new Point(0, 0);
            Point p2 = new Point(10, 0);
            Point pOnSegment = new Point(5, 0);
            Xunit.Assert.Equal(0.0, MainWindow.DistanceToSegment(pOnSegment, p1, p2), 3);

            // Точка на начале/конце сегмента (расстояние = 0)
            Xunit.Assert.Equal(0.0, MainWindow.DistanceToSegment(p1, p1, p2), 3);
            Xunit.Assert.Equal(0.0, MainWindow.DistanceToSegment(p2, p1, p2), 3);

            // Точка перпендикулярно к сегменту (горизонтальный сегмент)
            Point pPerp = new Point(5, 5);
            Xunit.Assert.Equal(5.0, MainWindow.DistanceToSegment(pPerp, p1, p2), 3);

            // Точка перпендикулярно к вертикальному сегменту
            Point p3 = new Point(0, 0);
            Point p4 = new Point(0, 10);
            Point pPerpVert = new Point(5, 5);
            Xunit.Assert.Equal(5.0, MainWindow.DistanceToSegment(pPerpVert, p3, p4), 3);

            // Точка на диагональном сегменте
            Point pDiag1 = new Point(0, 0);
            Point pDiag2 = new Point(10, 10);
            Point pOnDiag = new Point(5, 5);
            Xunit.Assert.Equal(0.0, MainWindow.DistanceToSegment(pOnDiag, pDiag1, pDiag2), 3);

            // ========== ПРОМЕЖУТОЧНЫЕ ВАРИАНТЫ (Граничные случаи) ==========

            // Точка на продолжении сегмента (проекция на начало)
            Point pLeft = new Point(-5, 0);
            Xunit.Assert.Equal(5.0, MainWindow.DistanceToSegment(pLeft, p1, p2), 3);

            // Точка на продолжении сегмента (проекция на конец)
            Point pRight = new Point(15, 0);
            Xunit.Assert.Equal(5.0, MainWindow.DistanceToSegment(pRight, p1, p2), 3);

            // Точка очень близко к сегменту
            Point pClose = new Point(5, 0.001);
            double actualClose = MainWindow.DistanceToSegment(pClose, p1, p2);
            Xunit.Assert.True(actualClose < 0.01);

            // Вырожденный сегмент (p1 == p2) - расстояние до точки
            Point pDegenerate = new Point(5, 5);
            Point pSame = new Point(0, 0);
            double expectedDegenerate = Math.Sqrt(5 * 5 + 5 * 5); // ~7.071
            Xunit.Assert.Equal(expectedDegenerate, MainWindow.DistanceToSegment(pDegenerate, pSame, pSame), 3);

            // Сегмент под углом 45 градусов, точка не на сегменте
            Point pAngle = new Point(0, 5);
            Point pAngle1 = new Point(0, 0);
            Point pAngle2 = new Point(10, 10);
            double actualAngle = MainWindow.DistanceToSegment(pAngle, pAngle1, pAngle2);
            Xunit.Assert.True(actualAngle > 3.5 && actualAngle < 3.6);

            // ========== НЕПРАВИЛЬНЫЕ/ЭКСТРЕМАЛЬНЫЕ ВАРИАНТЫ ==========

            // Отрицательные координаты
            Point pNeg = new Point(-5, -5);
            Point pNeg1 = new Point(-10, -10);
            Point pNeg2 = new Point(0, 0);
            Xunit.Assert.Equal(0.0, MainWindow.DistanceToSegment(pNeg, pNeg1, pNeg2), 3);

            // Очень большие координаты
            Point pLarge = new Point(1000000, 1000000);
            Point pLarge1 = new Point(0, 0);
            Point pLarge2 = new Point(2000000, 0);
            Xunit.Assert.Equal(1000000.0, MainWindow.DistanceToSegment(pLarge, pLarge1, pLarge2), 3);

            // Очень малые координаты
            Point pSmall = new Point(0.0001, 0.0001);
            Point pSmall1 = new Point(0, 0);
            Point pSmall2 = new Point(0.0002, 0);
            double actualSmall = MainWindow.DistanceToSegment(pSmall, pSmall1, pSmall2);
            Xunit.Assert.True(actualSmall < 0.0002);
        }

        [Fact]
        public void TestIsUcaFormatFile()
        {
            // ========== КОРРЕКТНЫЕ ВАРИАНТЫ: ФАЙЛЫ С РАСШИРЕНИЕМ .UCA ==========

            // Простой файл с расширением .uca
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("file.uca"));

            // Полный путь Windows
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("C:\\path\\to\\file.uca"));
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("C:\\Users\\Documents\\diagram.uca"));
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("D:\\Projects\\MyApp\\test.uca"));

            // Проверка регистронезависимости (все возможные комбинации регистра)
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("document.UCA")); // все заглавные
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("test.Uca")); // первая заглавная
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("myfile.uCa")); // вторая заглавная
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("file.UCa")); // первые две заглавные
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("file.UcA")); // первая и третья заглавные
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("file.uCA")); // последние две заглавные
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("file.UcA")); // смешанный регистр

            // Относительные пути
            Xunit.Assert.True(MainWindow.IsUcaFormatFile(".\\file.uca"));
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("..\\file.uca"));
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("folder\\file.uca"));
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("folder\\subfolder\\file.uca"));

            // Пути с пробелами в имени файла
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("my file.uca"));
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("C:\\My Documents\\file.uca"));
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("file name with spaces.uca"));

            // Пути с специальными символами
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("file-name.uca"));
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("file_name.uca"));
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("file123.uca"));
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("file(1).uca"));
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("file[test].uca"));

            // Пути с точками в имени файла (до расширения)
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("file.name.uca"));
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("file.name.test.uca"));
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("C:\\path\\file.name.uca"));

            // Очень длинные пути
            Xunit.Assert.True(MainWindow.IsUcaFormatFile(new string('a', 200) + ".uca"));
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("C:\\" + new string('a', 200) + ".uca"));

            // Пути с простыми именами (заменены Unicode на ASCII) - убраны, так как дублируют другие тесты

            // ========== ИСКЛЮЧИТЕЛЬНЫЕ ВАРИАНТЫ: NULL, ПУСТАЯ СТРОКА, ПРОБЕЛЫ ==========

            Xunit.Assert.False(MainWindow.IsUcaFormatFile(null));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile(""));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("   "));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("\t"));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("\n"));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("\r"));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("\t\n\r"));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile(" \t \n \r "));

            // ========== НЕПРАВИЛЬНЫЕ ВАРИАНТЫ: ДРУГИЕ РАСШИРЕНИЯ ==========

            // Стандартные расширения
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file.txt"));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file.doc"));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file.docx"));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file.pdf"));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file.xml"));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file.json"));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file.exe"));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file.dll"));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file.zip"));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file.rar"));

            // Похожие расширения (частично совпадающие)
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file.uc")); // короче
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file.ucaa")); // длиннее
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file.ucab"));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file.ucac"));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file.ucaa"));
            // Path.GetExtension("file.uca.") возвращает пустую строку "", поэтому метод вернет False
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file.uca.")); // точка в конце делает расширение пустым
            // Path.GetExtension("file.uca ") возвращает ".uca " (с пробелом), но функция обрезает пробелы, поэтому метод вернет True
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("file.uca ")); // пробел после расширения

            // Файлы без расширения
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file"));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file."));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("C:\\path\\file"));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("C:\\path\\file."));

            // Пути с несколькими расширениями (последнее не .uca)
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file.uca.backup"));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file.uca.txt"));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file.uca.old"));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("C:\\path\\file.uca.backup"));

            // Пути с расширением в середине имени
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file.uca.backup.txt"));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file.uca.test.doc"));

            // Только расширение - Path.GetExtension(".uca") возвращает пустую строку "" в .NET Framework
            // потому что строка начинается с точки и не содержит имени файла
            // Поэтому метод вернет False (расширение не совпадает с ".uca")
            Xunit.Assert.False(MainWindow.IsUcaFormatFile(".uca"));
            Xunit.Assert.False(MainWindow.IsUcaFormatFile(".UCA"));

            // Пути с пробелами вокруг расширения
            // Path.GetExtension("file .uca") возвращает ".uca", поэтому метод вернет True
            Xunit.Assert.True(MainWindow.IsUcaFormatFile("file .uca"));
            // Path.GetExtension("file. uca") возвращает пустую строку "" (пробел между точкой и расширением делает расширение невалидным), поэтому метод вернет False
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file. uca"));
            // Path.GetExtension("file . uca") возвращает пустую строку "" (пробел между точкой и расширением делает расширение невалидным), поэтому метод вернет False
            Xunit.Assert.False(MainWindow.IsUcaFormatFile("file . uca"));
        }

        [Fact]
        public void TestGetPathWithCorrectExtension()
        {
            // ========== КОРРЕКТНЫЕ ВАРИАНТЫ: ПУТИ С ПРАВИЛЬНЫМ РАСШИРЕНИЕМ .UCA ==========

            // Простые пути с расширением .uca (должны остаться без изменений)
            Xunit.Assert.Equal("file.uca", MainWindow.GetPathWithCorrectExtension("file.uca"));
            Xunit.Assert.Equal("document.uca", MainWindow.GetPathWithCorrectExtension("document.uca"));

            // Полные пути Windows с расширением .uca
            Xunit.Assert.Equal("C:\\path\\to\\file.uca", MainWindow.GetPathWithCorrectExtension("C:\\path\\to\\file.uca"));
            Xunit.Assert.Equal("C:\\Users\\Documents\\diagram.uca", MainWindow.GetPathWithCorrectExtension("C:\\Users\\Documents\\diagram.uca"));
            Xunit.Assert.Equal("D:\\Projects\\MyApp\\test.uca", MainWindow.GetPathWithCorrectExtension("D:\\Projects\\MyApp\\test.uca"));

            // Разные регистры расширения (должны остаться без изменений)
            Xunit.Assert.Equal("document.UCA", MainWindow.GetPathWithCorrectExtension("document.UCA"));
            Xunit.Assert.Equal("test.Uca", MainWindow.GetPathWithCorrectExtension("test.Uca"));
            Xunit.Assert.Equal("myfile.uCa", MainWindow.GetPathWithCorrectExtension("myfile.uCa"));
            Xunit.Assert.Equal("file.UCa", MainWindow.GetPathWithCorrectExtension("file.UCa"));

            // Относительные пути с расширением .uca
            Xunit.Assert.Equal(".\\file.uca", MainWindow.GetPathWithCorrectExtension(".\\file.uca"));
            Xunit.Assert.Equal("..\\file.uca", MainWindow.GetPathWithCorrectExtension("..\\file.uca"));
            Xunit.Assert.Equal("folder\\file.uca", MainWindow.GetPathWithCorrectExtension("folder\\file.uca"));

            // Пути с пробелами и расширением .uca
            Xunit.Assert.Equal("my file.uca", MainWindow.GetPathWithCorrectExtension("my file.uca"));
            Xunit.Assert.Equal("C:\\My Documents\\file.uca", MainWindow.GetPathWithCorrectExtension("C:\\My Documents\\file.uca"));

            // Пути с точками в имени и расширением .uca
            Xunit.Assert.Equal("file.name.uca", MainWindow.GetPathWithCorrectExtension("file.name.uca"));
            Xunit.Assert.Equal("file.name.test.uca", MainWindow.GetPathWithCorrectExtension("file.name.test.uca"));

            // ========== КОРРЕКТНЫЕ ВАРИАНТЫ: ПУТИ БЕЗ РАСШИРЕНИЯ ИЛИ С ДРУГИМ РАСШИРЕНИЕМ ==========

            // Файлы без расширения (должны получить .uca)
            Xunit.Assert.Equal("file.uca", MainWindow.GetPathWithCorrectExtension("file"));
            Xunit.Assert.Equal("document.uca", MainWindow.GetPathWithCorrectExtension("document"));
            Xunit.Assert.Equal("C:\\path\\file.uca", MainWindow.GetPathWithCorrectExtension("C:\\path\\file"));
            Xunit.Assert.Equal("C:\\path\\to\\diagram.uca", MainWindow.GetPathWithCorrectExtension("C:\\path\\to\\diagram"));

            // Файлы с точкой в конце (без расширения)
            // Path.ChangeExtension("file.", ".uca") возвращает "file.uca", а не "file..uca"
            Xunit.Assert.Equal("file.uca", MainWindow.GetPathWithCorrectExtension("file."));

            // Файлы с другими расширениями (должны получить .uca вместо них)
            Xunit.Assert.Equal("file.uca", MainWindow.GetPathWithCorrectExtension("file.txt"));
            Xunit.Assert.Equal("file.uca", MainWindow.GetPathWithCorrectExtension("file.doc"));
            Xunit.Assert.Equal("file.uca", MainWindow.GetPathWithCorrectExtension("file.docx"));
            Xunit.Assert.Equal("file.uca", MainWindow.GetPathWithCorrectExtension("file.pdf"));
            Xunit.Assert.Equal("file.uca", MainWindow.GetPathWithCorrectExtension("file.xml"));
            Xunit.Assert.Equal("file.uca", MainWindow.GetPathWithCorrectExtension("file.json"));
            Xunit.Assert.Equal("C:\\path\\diagram.uca", MainWindow.GetPathWithCorrectExtension("C:\\path\\diagram.doc"));
            Xunit.Assert.Equal("document.uca", MainWindow.GetPathWithCorrectExtension("document.pdf"));
            Xunit.Assert.Equal("C:\\Users\\test.uca", MainWindow.GetPathWithCorrectExtension("C:\\Users\\test.exe"));

            // Файлы с похожими расширениями
            Xunit.Assert.Equal("file.uca", MainWindow.GetPathWithCorrectExtension("file.uc"));
            Xunit.Assert.Equal("file.uca", MainWindow.GetPathWithCorrectExtension("file.ucaa"));
            Xunit.Assert.Equal("file.uca", MainWindow.GetPathWithCorrectExtension("file.ucab"));

            // Файлы с точками в имени и другим расширением
            Xunit.Assert.Equal("file.name.uca", MainWindow.GetPathWithCorrectExtension("file.name.txt"));
            Xunit.Assert.Equal("file.name.test.uca", MainWindow.GetPathWithCorrectExtension("file.name.test.doc"));
            Xunit.Assert.Equal("C:\\path\\file.name.uca", MainWindow.GetPathWithCorrectExtension("C:\\path\\file.name.pdf"));

            // Файлы с пробелами и другим расширением
            Xunit.Assert.Equal("my file.uca", MainWindow.GetPathWithCorrectExtension("my file.txt"));
            Xunit.Assert.Equal("C:\\My Documents\\file.uca", MainWindow.GetPathWithCorrectExtension("C:\\My Documents\\file.doc"));

            // Относительные пути без расширения или с другим расширением
            Xunit.Assert.Equal(".\\file.uca", MainWindow.GetPathWithCorrectExtension(".\\file"));
            Xunit.Assert.Equal(".\\file.uca", MainWindow.GetPathWithCorrectExtension(".\\file.txt"));
            Xunit.Assert.Equal("..\\file.uca", MainWindow.GetPathWithCorrectExtension("..\\file"));
            Xunit.Assert.Equal("folder\\file.uca", MainWindow.GetPathWithCorrectExtension("folder\\file.doc"));

            // ========== ИСКЛЮЧИТЕЛЬНЫЕ ВАРИАНТЫ: NULL, ПУСТАЯ СТРОКА, ПРОБЕЛЫ ==========

            Xunit.Assert.Null(MainWindow.GetPathWithCorrectExtension(null));
            Xunit.Assert.Equal("", MainWindow.GetPathWithCorrectExtension(""));
            Xunit.Assert.Equal("   ", MainWindow.GetPathWithCorrectExtension("   "));
            Xunit.Assert.Equal("\t", MainWindow.GetPathWithCorrectExtension("\t"));
            Xunit.Assert.Equal("\n", MainWindow.GetPathWithCorrectExtension("\n"));
            Xunit.Assert.Equal("\r", MainWindow.GetPathWithCorrectExtension("\r"));
            Xunit.Assert.Equal("\t\n\r", MainWindow.GetPathWithCorrectExtension("\t\n\r"));
            Xunit.Assert.Equal(" \t \n \r ", MainWindow.GetPathWithCorrectExtension(" \t \n \r "));

            // ========== ОСОБЫЕ СЛУЧАИ: ПУТИ С НЕСКОЛЬКИМИ РАСШИРЕНИЯМИ ==========

            // Path.ChangeExtension заменяет последнее расширение, поэтому "file.uca.backup" становится "file.uca.uca"
            Xunit.Assert.Equal("file.uca.uca", MainWindow.GetPathWithCorrectExtension("file.uca.backup"));
            // Path.ChangeExtension заменяет последнее расширение, поэтому "file.uca.txt" становится "file.uca.uca"
            Xunit.Assert.Equal("file.uca.uca", MainWindow.GetPathWithCorrectExtension("file.uca.txt"));
            // Path.ChangeExtension заменяет последнее расширение, поэтому "file.uca.old" становится "file.uca.uca"
            Xunit.Assert.Equal("file.uca.uca", MainWindow.GetPathWithCorrectExtension("file.uca.old"));
            // Path.ChangeExtension заменяет последнее расширение, поэтому "C:\\path\\file.uca.backup" становится "C:\\path\\file.uca.uca"
            Xunit.Assert.Equal("C:\\path\\file.uca.uca", MainWindow.GetPathWithCorrectExtension("C:\\path\\file.uca.backup"));

            // Пути с несколькими расширениями, где последнее не .uca
            Xunit.Assert.Equal("file.name.uca", MainWindow.GetPathWithCorrectExtension("file.name.txt"));
            Xunit.Assert.Equal("file.name.test.uca", MainWindow.GetPathWithCorrectExtension("file.name.test.doc"));

            // Пути с расширением в середине имени
            // Path.ChangeExtension заменяет последнее расширение, поэтому "file.uca.backup.txt" становится "file.uca.backup.uca"
            Xunit.Assert.Equal("file.uca.backup.uca", MainWindow.GetPathWithCorrectExtension("file.uca.backup.txt"));
            Xunit.Assert.Equal("file.uca.test.uca", MainWindow.GetPathWithCorrectExtension("file.uca.test.doc"));

            // ========== ОЧЕНЬ ДЛИННЫЕ ПУТИ ==========

            // Длинные имена файлов
            string longName = new string('a', 200);
            Xunit.Assert.Equal(longName + ".uca", MainWindow.GetPathWithCorrectExtension(longName));
            Xunit.Assert.Equal(longName + ".uca", MainWindow.GetPathWithCorrectExtension(longName + ".txt"));

            // Длинные пути
            string longPath = "C:\\" + new string('a', 200);
            Xunit.Assert.Equal(longPath + ".uca", MainWindow.GetPathWithCorrectExtension(longPath));
            Xunit.Assert.Equal(longPath + ".uca", MainWindow.GetPathWithCorrectExtension(longPath + ".doc"));

            // ========== UNICODE СИМВОЛЫ (заменены на ASCII) ==========

            // Пути с Unicode символами (заменены на ASCII)
            Xunit.Assert.Equal("file_ru.uca", MainWindow.GetPathWithCorrectExtension("file_ru"));
            Xunit.Assert.Equal("file_ru.uca", MainWindow.GetPathWithCorrectExtension("file_ru.txt"));
            Xunit.Assert.Equal("C:\\file_cn\\test.uca", MainWindow.GetPathWithCorrectExtension("C:\\file_cn\\test"));
            Xunit.Assert.Equal("C:\\file_cn\\test.uca", MainWindow.GetPathWithCorrectExtension("C:\\file_cn\\test.doc"));
            Xunit.Assert.Equal("test-file.uca", MainWindow.GetPathWithCorrectExtension("test-file.pdf"));

            // ========== СПЕЦИАЛЬНЫЕ СИМВОЛЫ ==========

            // Пути со специальными символами
            Xunit.Assert.Equal("file-name.uca", MainWindow.GetPathWithCorrectExtension("file-name"));
            Xunit.Assert.Equal("file_name.uca", MainWindow.GetPathWithCorrectExtension("file_name.txt"));
            Xunit.Assert.Equal("file123.uca", MainWindow.GetPathWithCorrectExtension("file123.doc"));
            Xunit.Assert.Equal("file(1).uca", MainWindow.GetPathWithCorrectExtension("file(1).pdf"));
            Xunit.Assert.Equal("file[test].uca", MainWindow.GetPathWithCorrectExtension("file[test].xml"));
        }

        [Fact]
        public void TestIsTextWithinLimits()
        {
            // Allowed: null/empty/whitespace
            Xunit.Assert.True(MainWindow.IsTextWithinLimits(null));
            Xunit.Assert.True(MainWindow.IsTextWithinLimits(string.Empty));
            Xunit.Assert.True(MainWindow.IsTextWithinLimits("   "));
            Xunit.Assert.True(MainWindow.IsTextWithinLimits("\t\n"));

            // Short text and boundary values
            Xunit.Assert.True(MainWindow.IsTextWithinLimits("Short text"));
            Xunit.Assert.True(MainWindow.IsTextWithinLimits(new string('A', 1)));
            Xunit.Assert.True(MainWindow.IsTextWithinLimits(new string('A', 20)));
            Xunit.Assert.True(MainWindow.IsTextWithinLimits(new string('A', 255)));
            Xunit.Assert.False(MainWindow.IsTextWithinLimits(new string('A', 256)));

            // Multi-line: only total length matters (no per-line cap)
            var linesWithinLimit = string.Join("\n", Enumerable.Range(0, 10).Select(i => new string('L', 20))); // 229 chars incl. newlines
            Xunit.Assert.True(MainWindow.IsTextWithinLimits(linesWithinLimit));

            var manyLinesStillWithin = string.Join("\n", Enumerable.Range(0, 5).Select(i => new string('X', 50))); // 254 chars incl. newlines
            Xunit.Assert.True(MainWindow.IsTextWithinLimits(manyLinesStillWithin));

            var overLimitMultiline = string.Join("\n", Enumerable.Range(0, 6).Select(i => new string('C', 50))); // >300 chars
            Xunit.Assert.False(MainWindow.IsTextWithinLimits(overLimitMultiline));

            // Carriage returns are removed before counting
            Xunit.Assert.True(MainWindow.IsTextWithinLimits("Line1\r\nLine2\rLine3"));

            // Mixed whitespace and content
            Xunit.Assert.True(MainWindow.IsTextWithinLimits("Text with spaces and tabs\t"));
            Xunit.Assert.True(MainWindow.IsTextWithinLimits("Line1\n\nLine3"));
        }

        [Fact]
        public void TestMeasureTextContent()
        {
            Exception? exception = null;
            var thread = new Thread(() =>
            {
                try
                {
                    // Инициализация WPF приложения для работы с UI элементами
                    if (System.Windows.Application.Current == null)
                    {
                        new System.Windows.Application();
                    }

                    // ========== КОРРЕКТНЫЕ ВАРИАНТЫ: НОРМАЛЬНЫЙ ТЕКСТ С ПАРАМЕТРАМИ ==========

                    // Короткий текст с разными шрифтами
                    var size1 = MainWindow.MeasureTextContent("Test", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(size1.Width > 0);
                    Xunit.Assert.True(size1.Height > 0);

                    var size2 = MainWindow.MeasureTextContent("Long text", new FontFamily("Times New Roman"), 16, FontWeights.Bold, 300);
                    Xunit.Assert.True(size2.Width > 0);
                    Xunit.Assert.True(size2.Height > 0);

                    // Разные стандартные шрифты
                    var sizeArial = MainWindow.MeasureTextContent("Test", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeArial.Width > 0 && sizeArial.Height > 0);

                    var sizeTimes = MainWindow.MeasureTextContent("Test", new FontFamily("Times New Roman"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeTimes.Width > 0 && sizeTimes.Height > 0);

                    var sizeCourier = MainWindow.MeasureTextContent("Test", new FontFamily("Courier New"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeCourier.Width > 0 && sizeCourier.Height > 0);

                    var sizeVerdana = MainWindow.MeasureTextContent("Test", new FontFamily("Verdana"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeVerdana.Width > 0 && sizeVerdana.Height > 0);

                    // Разные размеры шрифтов
                    var sizeSmall = MainWindow.MeasureTextContent("Test", new FontFamily("Arial"), 8, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeSmall.Width > 0 && sizeSmall.Height > 0);

                    var sizeMedium = MainWindow.MeasureTextContent("Test", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeMedium.Width > 0 && sizeMedium.Height > 0);

                    var sizeLarge = MainWindow.MeasureTextContent("Test", new FontFamily("Arial"), 24, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeLarge.Width > 0 && sizeLarge.Height > 0);

                    var sizeVeryLarge = MainWindow.MeasureTextContent("Test", new FontFamily("Arial"), 48, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeVeryLarge.Width > 0 && sizeVeryLarge.Height > 0);

                    // Разные веса шрифтов
                    var sizeThin = MainWindow.MeasureTextContent("Test", new FontFamily("Arial"), 14, FontWeights.Thin, 200);
                    Xunit.Assert.True(sizeThin.Width > 0 && sizeThin.Height > 0);

                    var sizeNormal = MainWindow.MeasureTextContent("Test", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeNormal.Width > 0 && sizeNormal.Height > 0);

                    var sizeBold = MainWindow.MeasureTextContent("Test", new FontFamily("Arial"), 14, FontWeights.Bold, 200);
                    Xunit.Assert.True(sizeBold.Width > 0 && sizeBold.Height > 0);

                    var sizeExtraBold = MainWindow.MeasureTextContent("Test", new FontFamily("Arial"), 14, FontWeights.ExtraBold, 200);
                    Xunit.Assert.True(sizeExtraBold.Width > 0 && sizeExtraBold.Height > 0);

                    // Разные максимальные ширины
                    var sizeNarrow = MainWindow.MeasureTextContent("Long text that will wrap", new FontFamily("Arial"), 14, FontWeights.Normal, 50);
                    Xunit.Assert.True(sizeNarrow.Width > 0 && sizeNarrow.Height > 0);

                    var sizeWide = MainWindow.MeasureTextContent("Long text", new FontFamily("Arial"), 14, FontWeights.Normal, 500);
                    Xunit.Assert.True(sizeWide.Width > 0 && sizeWide.Height > 0);

                    var sizeVeryWide = MainWindow.MeasureTextContent("Long text", new FontFamily("Arial"), 14, FontWeights.Normal, 1000);
                    Xunit.Assert.True(sizeVeryWide.Width > 0 && sizeVeryWide.Height > 0);

                    // Многострочный текст
                    var sizeMultiline = MainWindow.MeasureTextContent("Line1\nLine2\nLine3", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeMultiline.Width > 0 && sizeMultiline.Height > 0);

                    // Текст с переносами строк
                    var sizeWithBreaks = MainWindow.MeasureTextContent("First line\r\nSecond line", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeWithBreaks.Width > 0 && sizeWithBreaks.Height > 0);

                    // Длинный текст, который будет переноситься
                    var sizeLong = MainWindow.MeasureTextContent(new string('A', 100), new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeLong.Width > 0 && sizeLong.Height > 0);

                    // Текст с пробелами
                    var sizeSpaces = MainWindow.MeasureTextContent("Text with spaces", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeSpaces.Width > 0 && sizeSpaces.Height > 0);

                    // Текст с Unicode символами (заменены на ASCII)
                    var sizeUnicode = MainWindow.MeasureTextContent("Text in Russian", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeUnicode.Width > 0 && sizeUnicode.Height > 0);

                    var sizeChinese = MainWindow.MeasureTextContent("Chinese text", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeChinese.Width > 0 && sizeChinese.Height > 0);

                    // ========== КОРРЕКТНЫЕ ВАРИАНТЫ: С ДЕФОЛТНЫМИ ЗНАЧЕНИЯМИ ==========

                    // null FontFamily (должен использоваться "Inter")
                    var size3 = MainWindow.MeasureTextContent("Text", null, 0, default(FontWeight), 200);
                    Xunit.Assert.True(size3.Width > 0);
                    Xunit.Assert.True(size3.Height > 0);

                    // fontSize = 0 (должен использоваться 18)
                    var sizeZeroFont = MainWindow.MeasureTextContent("Text", new FontFamily("Arial"), 0, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeZeroFont.Width > 0 && sizeZeroFont.Height > 0);

                    // default FontWeight (должен использоваться SemiBold)
                    var sizeDefaultWeight = MainWindow.MeasureTextContent("Text", new FontFamily("Arial"), 14, default(FontWeight), 200);
                    Xunit.Assert.True(sizeDefaultWeight.Width > 0 && sizeDefaultWeight.Height > 0);

                    // Все дефолтные значения
                    var sizeAllDefaults = MainWindow.MeasureTextContent("Text", null, 0, default(FontWeight), 200);
                    Xunit.Assert.True(sizeAllDefaults.Width > 0 && sizeAllDefaults.Height > 0);

                    // ========== ИСКЛЮЧИТЕЛЬНЫЕ ВАРИАНТЫ: ПУСТОЙ ИЛИ NULL ТЕКСТ ==========

                    // null текст (должен использоваться дефолтный текст)
                    var size4 = MainWindow.MeasureTextContent(null, new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(size4.Width > 0);
                    Xunit.Assert.True(size4.Height > 0);

                    // Пустая строка (должна использоваться дефолтный текст)
                    var size5 = MainWindow.MeasureTextContent("", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(size5.Width > 0);
                    Xunit.Assert.True(size5.Height > 0);

                    // Только пробелы (должна использоваться дефолтный текст)
                    var sizeWhitespace = MainWindow.MeasureTextContent("   ", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeWhitespace.Width > 0 && sizeWhitespace.Height > 0);

                    // ========== НЕПРАВИЛЬНЫЕ ВАРИАНТЫ: ГРАНИЧНЫЕ И ЭКСТРЕМАЛЬНЫЕ ЗНАЧЕНИЯ ==========

                    // Отрицательный размер шрифта (должен использоваться 18)
                    var size6 = MainWindow.MeasureTextContent("Test", new FontFamily("Arial"), -5, FontWeights.Normal, 200);
                    Xunit.Assert.True(size6.Width > 0);
                    Xunit.Assert.True(size6.Height > 0);

                    // Очень маленький размер шрифта
                    var sizeTiny = MainWindow.MeasureTextContent("Test", new FontFamily("Arial"), 1, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeTiny.Width > 0 && sizeTiny.Height > 0);

                    // Очень большой размер шрифта
                    var sizeHuge = MainWindow.MeasureTextContent("Test", new FontFamily("Arial"), 200, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeHuge.Width > 0 && sizeHuge.Height > 0);

                    // Максимальная ширина = 0 (может вызвать проблемы, но должен обработаться)
                    var sizeZeroWidth = MainWindow.MeasureTextContent("Test", new FontFamily("Arial"), 14, FontWeights.Normal, 0);
                    Xunit.Assert.True(sizeZeroWidth.Width >= 0 && sizeZeroWidth.Height > 0);

                    // Отрицательная максимальная ширина (может вызвать исключение, поэтому пропускаем этот тест)
                    // var sizeNegWidth = MainWindow.MeasureTextContent("Test", new FontFamily("Arial"), 14, FontWeights.Normal, -100);
                    // Xunit.Assert.True(sizeNegWidth.Width >= 0 && sizeNegWidth.Height > 0);

                    // Очень большая максимальная ширина
                    var sizeMaxWidth = MainWindow.MeasureTextContent("Test", new FontFamily("Arial"), 14, FontWeights.Normal, double.MaxValue);
                    Xunit.Assert.True(sizeMaxWidth.Width > 0 && sizeMaxWidth.Height > 0);

                    // Очень длинный текст с очень узкой шириной
                    var sizeLongNarrow = MainWindow.MeasureTextContent(new string('A', 1000), new FontFamily("Arial"), 14, FontWeights.Normal, 10);
                    Xunit.Assert.True(sizeLongNarrow.Width > 0 && sizeLongNarrow.Height > 0);

                    // Текст с множеством переносов строк
                    var sizeManyBreaks = MainWindow.MeasureTextContent(string.Join("\n", Enumerable.Range(0, 50).Select(i => "Line" + i)), new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeManyBreaks.Width > 0 && sizeManyBreaks.Height > 0);

                    // Специальные символы
                    var sizeSpecial = MainWindow.MeasureTextContent("!@#$%^&*()_+-=[]{}|;':\",./<>?", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeSpecial.Width > 0 && sizeSpecial.Height > 0);

                    // Только цифры
                    var sizeNumbers = MainWindow.MeasureTextContent("1234567890", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeNumbers.Width > 0 && sizeNumbers.Height > 0);

                    // Только символы
                    var sizeSymbols = MainWindow.MeasureTextContent("ABCDEFGHIJKLMNOPQRSTUVWXYZ", new FontFamily("Arial"), 14, FontWeights.Normal, 200);
                    Xunit.Assert.True(sizeSymbols.Width > 0 && sizeSymbols.Height > 0);
                }
                catch (Exception ex) { exception = ex; }
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            thread.Join();
            if (exception != null) throw exception;
        }

        [Fact]
        public void TestIsTextContainer()
        {
            Exception? exception = null;
            var thread = new Thread(() =>
            {
                try
                {
                    // Инициализация WPF приложения для работы с UI элементами
                    if (System.Windows.Application.Current == null)
                    {
                        new System.Windows.Application();
                    }

                    // ========== КОРРЕКТНЫЕ ВАРИАНТЫ: BORDER С ПРАВИЛЬНЫМ ТЕГОМ "uca-user-text" ==========

                    // Border с правильным тегом (точное совпадение)
                    var border1 = new Border { Tag = "uca-user-text" };
                    Xunit.Assert.True(MainWindow.IsTextContainer(border1));

                    var border2 = new Border { Tag = "uca-user-text" };
                    Xunit.Assert.True(MainWindow.IsTextContainer(border2));

                    // Border с правильным тегом и дополнительными свойствами
                    var borderWithProps = new Border
                    {
                        Tag = "uca-user-text",
                        Width = 100,
                        Height = 50,
                        Background = Brushes.White
                    };
                    Xunit.Assert.True(MainWindow.IsTextContainer(borderWithProps));

                    // Border с правильным тегом и дочерним элементом
                    var borderWithChild = new Border { Tag = "uca-user-text" };
                    borderWithChild.Child = new TextBlock { Text = "Test" };
                    Xunit.Assert.True(MainWindow.IsTextContainer(borderWithChild));

                    // ========== ИСКЛЮЧИТЕЛЬНЫЕ ВАРИАНТЫ: NULL, BORDER БЕЗ ТЕГА, BORDER С NULL ТЕГОМ ==========

                    // null элемент
                    Xunit.Assert.False(MainWindow.IsTextContainer(null));

                    // Border с null тегом
                    var border3 = new Border { Tag = null };
                    Xunit.Assert.False(MainWindow.IsTextContainer(border3));

                    // Border без тега (Tag не установлен)
                    var border4 = new Border();
                    Xunit.Assert.False(MainWindow.IsTextContainer(border4));

                    // Border с пустой строкой в теге
                    var borderEmpty = new Border { Tag = "" };
                    Xunit.Assert.False(MainWindow.IsTextContainer(borderEmpty));

                    // Border только с пробелами в теге
                    var borderWhitespace = new Border { Tag = "   " };
                    Xunit.Assert.False(MainWindow.IsTextContainer(borderWhitespace));

                    // ========== НЕПРАВИЛЬНЫЕ ВАРИАНТЫ: BORDER С НЕПРАВИЛЬНЫМ ТЕГОМ ==========

                    // Border с неправильным тегом (полностью другой)
                    var border5 = new Border { Tag = "wrong-tag" };
                    Xunit.Assert.False(MainWindow.IsTextContainer(border5));

                    var borderWrong1 = new Border { Tag = "user-text" };
                    Xunit.Assert.False(MainWindow.IsTextContainer(borderWrong1));

                    var borderWrong2 = new Border { Tag = "uca-text" };
                    Xunit.Assert.False(MainWindow.IsTextContainer(borderWrong2));

                    // Border с тегом в другом регистре (регистрозависимая проверка)
                    var border6 = new Border { Tag = "UCA-USER-TEXT" };
                    Xunit.Assert.False(MainWindow.IsTextContainer(border6));

                    var borderUpper = new Border { Tag = "UCA-USER-TEXT" };
                    Xunit.Assert.False(MainWindow.IsTextContainer(borderUpper));

                    var borderLower = new Border { Tag = "uca-user-text" };
                    Xunit.Assert.True(MainWindow.IsTextContainer(borderLower)); // правильный регистр

                    // Border с тегом, содержащим "uca-user-text" как подстроку
                    var borderSubstring1 = new Border { Tag = "prefix-uca-user-text" };
                    Xunit.Assert.False(MainWindow.IsTextContainer(borderSubstring1));

                    var borderSubstring2 = new Border { Tag = "uca-user-text-suffix" };
                    Xunit.Assert.False(MainWindow.IsTextContainer(borderSubstring2));

                    var borderSubstring3 = new Border { Tag = "uca-user-text-extra" };
                    Xunit.Assert.False(MainWindow.IsTextContainer(borderSubstring3));

                    // Border с похожим тегом
                    var borderSimilar1 = new Border { Tag = "uca-user-tex" };
                    Xunit.Assert.False(MainWindow.IsTextContainer(borderSimilar1));

                    var borderSimilar2 = new Border { Tag = "uca-user-textt" };
                    Xunit.Assert.False(MainWindow.IsTextContainer(borderSimilar2));

                    var borderSimilar3 = new Border { Tag = "uca-user-tex-" };
                    Xunit.Assert.False(MainWindow.IsTextContainer(borderSimilar3));

                    // Border с тегом, содержащим пробелы
                    var borderSpaces = new Border { Tag = "uca-user-text " };
                    Xunit.Assert.False(MainWindow.IsTextContainer(borderSpaces));

                    var borderSpaces2 = new Border { Tag = " uca-user-text" };
                    Xunit.Assert.False(MainWindow.IsTextContainer(borderSpaces2));

                    var borderSpaces3 = new Border { Tag = "uca-user- text" };
                    Xunit.Assert.False(MainWindow.IsTextContainer(borderSpaces3));

                    // ========== НЕПРАВИЛЬНЫЕ ВАРИАНТЫ: ДРУГИЕ ЭЛЕМЕНТЫ ==========

                    // TextBlock с правильным тегом (не Border)
                    var textBlock = new TextBlock { Tag = "uca-user-text" };
                    Xunit.Assert.False(MainWindow.IsTextContainer(textBlock));

                    // Button с правильным тегом (не Border)
                    var button = new Button { Tag = "uca-user-text" };
                    Xunit.Assert.False(MainWindow.IsTextContainer(button));

                    // Canvas с правильным тегом (не Border)
                    var canvas = new Canvas { Tag = "uca-user-text" };
                    Xunit.Assert.False(MainWindow.IsTextContainer(canvas));

                    // Grid с правильным тегом (не Border)
                    var grid = new Grid { Tag = "uca-user-text" };
                    Xunit.Assert.False(MainWindow.IsTextContainer(grid));

                    // StackPanel с правильным тегом (не Border)
                    var stackPanel = new StackPanel { Tag = "uca-user-text" };
                    Xunit.Assert.False(MainWindow.IsTextContainer(stackPanel));

                    // ========== НЕПРАВИЛЬНЫЕ ВАРИАНТЫ: ТЕГ НЕ СТРОКА ==========

                    // Border с числовым тегом
                    var border7 = new Border { Tag = 123 };
                    Xunit.Assert.False(MainWindow.IsTextContainer(border7));

                    var borderInt = new Border { Tag = 0 };
                    Xunit.Assert.False(MainWindow.IsTextContainer(borderInt));

                    var borderIntNeg = new Border { Tag = -1 };
                    Xunit.Assert.False(MainWindow.IsTextContainer(borderIntNeg));

                    // Border с объектным тегом
                    var borderObj = new Border { Tag = new object() };
                    Xunit.Assert.False(MainWindow.IsTextContainer(borderObj));

                    // Border с bool тегом
                    var borderBool = new Border { Tag = true };
                    Xunit.Assert.False(MainWindow.IsTextContainer(borderBool));

                    // Border с DateTime тегом
                    var borderDate = new Border { Tag = DateTime.Now };
                    Xunit.Assert.False(MainWindow.IsTextContainer(borderDate));
                }
                catch (Exception ex) { exception = ex; }
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            thread.Join();
            if (exception != null) throw exception;
        }

        [Fact]
        public void TestIsUserText()
        {
            Exception? exception = null;
            var thread = new Thread(() =>
            {
                try
                {
                    // Инициализация WPF приложения для работы с UI элементами
                    if (System.Windows.Application.Current == null)
                    {
                        new System.Windows.Application();
                    }

                    // ========== КОРРЕКТНЫЕ ВАРИАНТЫ: TEXTBLOCK С ПРАВИЛЬНЫМ ТЕГОМ ==========

                    // TextBlock с правильным тегом "uca-user-text" без текста
                    var textBlock1 = new TextBlock { Tag = "uca-user-text" };
                    Xunit.Assert.True(MainWindow.IsUserText(textBlock1));

                    // TextBlock с правильным тегом "uca-user-text" и с текстом
                    var textBlock2 = new TextBlock { Tag = "uca-user-text", Text = "Test" };
                    Xunit.Assert.True(MainWindow.IsUserText(textBlock2));

                    // TextBlock с правильным тегом и длинным текстом
                    var textBlockLong = new TextBlock { Tag = "uca-user-text", Text = new string('A', 100) };
                    Xunit.Assert.True(MainWindow.IsUserText(textBlockLong));

                    // TextBlock с правильным тегом и пустым текстом
                    var textBlockEmpty = new TextBlock { Tag = "uca-user-text", Text = "" };
                    Xunit.Assert.True(MainWindow.IsUserText(textBlockEmpty));

                    // TextBlock с правильным тегом и текстом с пробелами
                    var textBlockSpaces = new TextBlock { Tag = "uca-user-text", Text = "   " };
                    Xunit.Assert.True(MainWindow.IsUserText(textBlockSpaces));

                    // TextBlock с правильным тегом и Unicode текстом (заменен на ASCII)
                    var textBlockUnicode = new TextBlock { Tag = "uca-user-text", Text = "Text in Russian" };
                    Xunit.Assert.True(MainWindow.IsUserText(textBlockUnicode));

                    // TextBlock с правильным тегом и дополнительными свойствами
                    var textBlockWithProps = new TextBlock
                    {
                        Tag = "uca-user-text",
                        Text = "Test",
                        FontSize = 14,
                        Foreground = Brushes.Black
                    };
                    Xunit.Assert.True(MainWindow.IsUserText(textBlockWithProps));

                    // ========== КОРРЕКТНЫЕ ВАРИАНТЫ: TEXTBLOCK ВНУТРИ BORDER С ПРАВИЛЬНЫМ ТЕГОМ ==========

                    // TextBlock внутри Border с правильным тегом "uca-user-text"
                    var border = new Border { Tag = "uca-user-text" };
                    var textBlock3 = new TextBlock { Text = "Test" };
                    border.Child = textBlock3;
                    Xunit.Assert.True(MainWindow.IsUserText(textBlock3));

                    // TextBlock без тега внутри Border с правильным тегом
                    var border2 = new Border { Tag = "uca-user-text" };
                    var textBlockNoTag = new TextBlock { Text = "Test" };
                    border2.Child = textBlockNoTag;
                    Xunit.Assert.True(MainWindow.IsUserText(textBlockNoTag));

                    // TextBlock с неправильным тегом внутри Border с правильным тегом (должен быть распознан)
                    var border3 = new Border { Tag = "uca-user-text" };
                    var textBlockWrongTag = new TextBlock { Tag = "wrong-tag", Text = "Test" };
                    border3.Child = textBlockWrongTag;
                    Xunit.Assert.True(MainWindow.IsUserText(textBlockWrongTag));

                    // TextBlock с правильным тегом внутри Border с правильным тегом
                    var border4 = new Border { Tag = "uca-user-text" };
                    var textBlockBothTags = new TextBlock { Tag = "uca-user-text", Text = "Test" };
                    border4.Child = textBlockBothTags;
                    Xunit.Assert.True(MainWindow.IsUserText(textBlockBothTags));

                    // TextBlock без текста внутри Border с правильным тегом
                    var border5 = new Border { Tag = "uca-user-text" };
                    var textBlockNoText = new TextBlock();
                    border5.Child = textBlockNoText;
                    Xunit.Assert.True(MainWindow.IsUserText(textBlockNoText));

                    // ========== ИСКЛЮЧИТЕЛЬНЫЕ ВАРИАНТЫ: NULL ==========

                    // null должен вернуть false (защита от NullReferenceException)
                    Xunit.Assert.False(MainWindow.IsUserText(null));

                    // ========== НЕПРАВИЛЬНЫЕ ВАРИАНТЫ: TEXTBLOCK БЕЗ ПРАВИЛЬНОГО ТЕГА И НЕ В КОНТЕЙНЕРЕ ==========

                    // TextBlock без тега и не находящийся в контейнере
                    var textBlock4 = new TextBlock { Text = "Test" };
                    Xunit.Assert.False(MainWindow.IsUserText(textBlock4));

                    // TextBlock с null тегом и не в контейнере
                    var textBlock5 = new TextBlock { Tag = null, Text = "Test" };
                    Xunit.Assert.False(MainWindow.IsUserText(textBlock5));

                    // TextBlock с пустой строкой в теге
                    var textBlockEmptyTag = new TextBlock { Tag = "", Text = "Test" };
                    Xunit.Assert.False(MainWindow.IsUserText(textBlockEmptyTag));

                    // TextBlock с пробелами в теге
                    var textBlockWhitespaceTag = new TextBlock { Tag = "   ", Text = "Test" };
                    Xunit.Assert.False(MainWindow.IsUserText(textBlockWhitespaceTag));

                    // ========== НЕПРАВИЛЬНЫЕ ВАРИАНТЫ: TEXTBLOCK С НЕПРАВИЛЬНЫМ ТЕГОМ ==========

                    // TextBlock с неправильным тегом
                    var textBlock6 = new TextBlock { Tag = "wrong-tag" };
                    Xunit.Assert.False(MainWindow.IsUserText(textBlock6));

                    var textBlockWrong1 = new TextBlock { Tag = "user-text" };
                    Xunit.Assert.False(MainWindow.IsUserText(textBlockWrong1));

                    var textBlockWrong2 = new TextBlock { Tag = "uca-text" };
                    Xunit.Assert.False(MainWindow.IsUserText(textBlockWrong2));

                    // TextBlock с тегом в другом регистре (регистрозависимая проверка)
                    var textBlock7 = new TextBlock { Tag = "UCA-USER-TEXT" };
                    Xunit.Assert.False(MainWindow.IsUserText(textBlock7));

                    var textBlockUpper = new TextBlock { Tag = "UCA-USER-TEXT", Text = "Test" };
                    Xunit.Assert.False(MainWindow.IsUserText(textBlockUpper));

                    var textBlockMixed = new TextBlock { Tag = "Uca-User-Text", Text = "Test" };
                    Xunit.Assert.False(MainWindow.IsUserText(textBlockMixed));

                    // TextBlock с тегом, содержащим "uca-user-text" как подстроку
                    var textBlockSubstring1 = new TextBlock { Tag = "prefix-uca-user-text" };
                    Xunit.Assert.False(MainWindow.IsUserText(textBlockSubstring1));

                    var textBlockSubstring2 = new TextBlock { Tag = "uca-user-text-suffix" };
                    Xunit.Assert.False(MainWindow.IsUserText(textBlockSubstring2));

                    // TextBlock с похожим тегом
                    var textBlockSimilar1 = new TextBlock { Tag = "uca-user-tex" };
                    Xunit.Assert.False(MainWindow.IsUserText(textBlockSimilar1));

                    var textBlockSimilar2 = new TextBlock { Tag = "uca-user-textt" };
                    Xunit.Assert.False(MainWindow.IsUserText(textBlockSimilar2));

                    // TextBlock с тегом, содержащим пробелы
                    var textBlockTagSpaces1 = new TextBlock { Tag = "uca-user-text " };
                    Xunit.Assert.False(MainWindow.IsUserText(textBlockTagSpaces1));

                    var textBlockTagSpaces2 = new TextBlock { Tag = " uca-user-text" };
                    Xunit.Assert.False(MainWindow.IsUserText(textBlockTagSpaces2));

                    // ========== НЕПРАВИЛЬНЫЕ ВАРИАНТЫ: TEXTBLOCK ВНУТРИ BORDER С НЕПРАВИЛЬНЫМ ТЕГОМ ==========

                    // TextBlock внутри Border с неправильным тегом
                    var borderWrong = new Border { Tag = "wrong-tag" };
                    var textBlock8 = new TextBlock { Text = "Test" };
                    borderWrong.Child = textBlock8;
                    Xunit.Assert.False(MainWindow.IsUserText(textBlock8));

                    // TextBlock внутри Border без тега
                    var borderNoTag = new Border();
                    var textBlock9 = new TextBlock { Text = "Test" };
                    borderNoTag.Child = textBlock9;
                    Xunit.Assert.False(MainWindow.IsUserText(textBlock9));

                    // TextBlock внутри Border с null тегом
                    var borderNullTag = new Border { Tag = null };
                    var textBlock10 = new TextBlock { Text = "Test" };
                    borderNullTag.Child = textBlock10;
                    Xunit.Assert.False(MainWindow.IsUserText(textBlock10));

                    // TextBlock внутри Border с тегом в другом регистре
                    var borderWrongCase = new Border { Tag = "UCA-USER-TEXT" };
                    var textBlock11 = new TextBlock { Text = "Test" };
                    borderWrongCase.Child = textBlock11;
                    Xunit.Assert.False(MainWindow.IsUserText(textBlock11));

                    // TextBlock внутри Border с похожим тегом
                    var borderSimilar = new Border { Tag = "uca-user-tex" };
                    var textBlock12 = new TextBlock { Text = "Test" };
                    borderSimilar.Child = textBlock12;
                    Xunit.Assert.False(MainWindow.IsUserText(textBlock12));

                    // ========== НЕПРАВИЛЬНЫЕ ВАРИАНТЫ: TEXTBLOCK ВНУТРИ ДРУГИХ КОНТЕЙНЕРОВ ==========

                    // TextBlock внутри Canvas (не Border)
                    var canvas = new Canvas();
                    var textBlockInCanvas = new TextBlock { Text = "Test" };
                    canvas.Children.Add(textBlockInCanvas);
                    Xunit.Assert.False(MainWindow.IsUserText(textBlockInCanvas));

                    // TextBlock внутри Grid (не Border)
                    var grid = new Grid();
                    var textBlockInGrid = new TextBlock { Text = "Test" };
                    grid.Children.Add(textBlockInGrid);
                    Xunit.Assert.False(MainWindow.IsUserText(textBlockInGrid));

                    // TextBlock внутри StackPanel (не Border)
                    var stackPanel = new StackPanel();
                    var textBlockInStack = new TextBlock { Text = "Test" };
                    stackPanel.Children.Add(textBlockInStack);
                    Xunit.Assert.False(MainWindow.IsUserText(textBlockInStack));

                    // ========== НЕПРАВИЛЬНЫЕ ВАРИАНТЫ: ТЕГ НЕ СТРОКА ==========

                    // TextBlock с числовым тегом
                    var textBlockIntTag = new TextBlock { Tag = 123, Text = "Test" };
                    Xunit.Assert.False(MainWindow.IsUserText(textBlockIntTag));

                    // TextBlock с объектным тегом
                    var textBlockObjTag = new TextBlock { Tag = new object(), Text = "Test" };
                    Xunit.Assert.False(MainWindow.IsUserText(textBlockObjTag));

                    // TextBlock с bool тегом
                    var textBlockBoolTag = new TextBlock { Tag = true, Text = "Test" };
                    Xunit.Assert.False(MainWindow.IsUserText(textBlockBoolTag));

                    // ========== ОСОБЫЕ СЛУЧАИ: ВЛОЖЕННЫЕ КОНТЕЙНЕРЫ ==========

                    // TextBlock внутри Border, который внутри другого Border (проверка только прямого родителя)
                    var outerBorder = new Border { Tag = "wrong-tag" };
                    var innerBorder = new Border { Tag = "uca-user-text" };
                    var textBlockNested = new TextBlock { Text = "Test" };
                    innerBorder.Child = textBlockNested;
                    outerBorder.Child = innerBorder;
                    // Должен быть распознан, так как прямой родитель - Border с правильным тегом
                    Xunit.Assert.True(MainWindow.IsUserText(textBlockNested));
                }
                catch (Exception ex) { exception = ex; }
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            thread.Join();
            if (exception != null) throw exception;
        }
    }
}
