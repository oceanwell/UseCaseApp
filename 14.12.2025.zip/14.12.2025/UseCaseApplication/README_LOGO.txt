Инструкция по добавлению логотипа:

1. Поместите файл logo.png в папку проекта: C:\LoadApp\VOLGGTY2\kachestvo i nadezhnost is\UseCaseApplication\UseCaseApplication\

2. В Visual Studio:
   - Щелкните правой кнопкой по файлу logo.png в Solution Explorer
   - Выберите Properties (Свойства)
   - Установите "Build Action" = "Resource"
   - Установите "Copy to Output Directory" = "Copy if newer"

3. Если файл logo.png отсутствует, логотип просто не будет отображаться, но приложение будет работать нормально.

Рекомендуемый размер логотипа: 120x48 пикселей (или пропорциональный)
Формат: PNG с прозрачным фоном

